//  SPDX-FileCopyrightText: 1998 Matthias Hoelzer <hoelzer@kde.org>
//  SPDX-FileCopyrightText: 2002-2005 David Faure <faure@kde.org>
//  SPDX-License-Identifier: GPL-2.0-or-later

// Own
#include <config-kdialog.h>
#include "widgets.h"
#include "utils.h"
#include <iostream>

// Qt

#include <QtCore>
#include <QtGui>
#include <QPalette>
#include <QComboBox>
#include <QDebug>
#include <QFile>
#include <QInputDialog>
#include <QTextStream>
#include <QTextCursor>
#include <QLabel>
#include <QVBoxLayout>
#include <QPixmap>

#include <QtWidgets>

// KF
#include <KPasswordDialog>
#include <KNewPasswordDialog>
#include <KTextEdit>
#include <KDatePicker>
#include <KLocalizedString>


#include <kmodifierkeyinfo.h>

// Local
#include "klistboxdialog.h"
#include "progressdialog.h"

#include "NcFramelessHelper.h"

#define s32 26

#include "NcFramelessHelper.cpp"

extern void qt_set_sequence_auto_mnemonic(bool);


static QString pla=QString::fromUtf8(" ");


QPushButton *m_AButton;
QPushButton *m_OButton;
QPushButton *m_EButton;

QPalette *palette = new QPalette();

static void myrepaint(void);
static void myrepaintline(void);
static bool altkey=false;
static bool ctrlkey=false;
static bool cancel_altkey=false;
static bool hold_altkey=false;
static bool hold_shiftkey=false;
static bool hold_capslockkey=false;

static int ret_line=0;
static int VCenter=0;
static int adjust;
static bool hidden=false;


static void inserttext(QString pla);
static void inserttextline(QString pla);

static QWidget *parent;
//static MyLineEdit *line_edit;


class MyLineEdit : public QLineEdit
{

public:
explicit MyLineEdit(QWidget *parent = 0);
void mousePressEvent(QMouseEvent *e);
void mouseReleaseEvent(QMouseEvent *e);
void keyPressEvent(QKeyEvent * e);
void keyReleaseEvent(QKeyEvent * e);
bool focusNextPrevChild(bool next);
bool eventFilter(QObject *object, QEvent *event);
QWidget *parent;
};

MyLineEdit::MyLineEdit(QWidget *parent) : QLineEdit(parent)
{
    parent=parent;
}

bool MyLineEdit::eventFilter(QObject *object, QEvent *event)
{
    if(event->type() == QEvent::KeyPress)
    {
        QKeyEvent* keyEvent = static_cast<QKeyEvent *>(event);
        if(keyEvent->key() == Qt::Key_Tab || keyEvent->key() == Qt::Key_Backtab)
        {
            QApplication::postEvent(this, new QKeyEvent(keyEvent->type(), keyEvent->key(), keyEvent->modifiers()));
            // Filter this event because the editor will be closed anyway
            return true;
        }
    }
    else if(event->type() == QEvent::FocusOut)
    {
        QFocusEvent* focusEvent = static_cast<QFocusEvent *>(event);
        QApplication::postEvent(this, new QFocusEvent(focusEvent->type(), focusEvent->reason()));

        // Don't filter because focus can be changed internally in editor
        return false;
    }

    return QWidget::eventFilter(object, event);
}


void MyLineEdit::mousePressEvent(QMouseEvent *event)
{
  qDebug() << "mouse pressed";
  if(event->button() == Qt::RightButton)
    {
      QString my_text = this->text();
      int length = my_text.length();
      if (length==0)
     {
      QKeyEvent *keyEvent = new QKeyEvent(QEvent::KeyPress, Qt::Key_Escape, Qt::NoModifier, QString(QChar(Qt::Key_Escape)));
        QApplication::sendEvent(this, (QEvent *)keyEvent);
     }
    }
    /*
    else if(event->button() == Qt::LeftButton)
    {
      //event->setAccepted(true);
      //MyLineEdit::rejected();
      QKeyEvent *keyEvent = new QKeyEvent(QEvent::KeyPress, Qt::Key_Enter, Qt::NoModifier, QString(QChar(Qt::Key_Enter)));
        QApplication::sendEvent(this, (QEvent *)keyEvent);
    }
    */
  QLineEdit::mousePressEvent( event);
}

void MyLineEdit::mouseReleaseEvent(QMouseEvent *event)
{
  qDebug() << "mouse release";
  QLineEdit::mouseReleaseEvent( event);
}


void MyLineEdit::keyPressEvent(QKeyEvent *e)
{
  bool shiftkey;

//if ((e->modifiers() & Qt::ControlModifier) && (e->key()==Qt::Key_Return || e->key()==Qt::Key_Enter|| e->key()==Qt::Key_Space) )
  if (e->key()==Qt::Key_Tab)
  {
    qDebug() << "Tab pressed";
    ret_line=-1;
    qDebug() << ret_line;
    m_OButton->animateClick();
    e->ignore();
  }
  if ((e->key()==Qt::Key_Return) || (e->key()==Qt::Key_Enter))
    {
        qDebug() << "Enter pressed";
        ret_line=0;
        m_OButton->animateClick();
        e->ignore();
    }
  if (e->key() == Qt::Key_Alt) {
  qDebug() << "Alt pressed";

  myrepaintline();
  altkey=!altkey;
  hold_altkey=true;
  m_AButton->setEnabled(altkey);
  e->ignore();
  }
 else if (e->key() == Qt::Key_Shift) {
  qDebug() << "Shift pressed";
  hold_shiftkey=true;
  e->ignore();
  }
  else if (e->key() == Qt::Key_Control) {
  qDebug() << "Ctrl pressed";
  ctrlkey=true;
  e->ignore();
  }
  else
  {

    KModifierKeyInfo info;
    hold_capslockkey = info.isKeyLocked(Qt::Key_CapsLock);
    if (((hold_capslockkey) && (!hold_shiftkey)) || ((!hold_capslockkey) && (hold_shiftkey))) shiftkey=true;
    else shiftkey=false;
    if (altkey)
    {
      switch (e->key())
      {
        case Qt::Key_8:
          pla=QString::fromUtf8("°");
          inserttextline(pla);
          break;
        case Qt::Key_3:
          pla=QString::fromUtf8("³");
          inserttextline(pla);
          break;
        case Qt::Key_2:
          pla=QString::fromUtf8("²");
          inserttextline(pla);
          break;
        case Qt::Key_Minus:
          pla=QString::fromUtf8("±");
          inserttextline(pla);
          break;
        case Qt::Key_Slash:
          pla=QString::fromUtf8("÷");
          inserttextline(pla);
          break;
        case Qt::Key_Stop:
          pla=QString::fromUtf8("·");
          inserttextline(pla);
          break;
        case Qt::Key_1:
          pla=QString::fromUtf8("½");
          inserttextline(pla);
          break;
        case Qt::Key_4:
          pla=QString::fromUtf8("¼");
          inserttextline(pla);
          break;
        case Qt::Key_5:
          pla=QString::fromUtf8("¾");
          inserttextline(pla);
          break;
        case Qt::Key_0:
          pla=QString::fromUtf8("Ø");
          inserttextline(pla);
          break;
        case Qt::Key_A:
          if (shiftkey) pla=QString::fromUtf8("Α");
          else pla=QString::fromUtf8("α");
          inserttextline(pla);
          break;
        case Qt::Key_B:
          if (shiftkey) pla=QString::fromUtf8("Β");
          else pla=QString::fromUtf8("β");
          inserttextline(pla);
          break;
        case Qt::Key_G:
          if (shiftkey) pla=QString::fromUtf8("Γ");
          else pla=QString::fromUtf8("γ");
          inserttextline(pla);
          break;
        case Qt::Key_D:
          if (shiftkey) pla=QString::fromUtf8("Δ");
          else pla=QString::fromUtf8("δ");
          inserttextline(pla);
          break;
        case Qt::Key_E:
          if (shiftkey) pla=QString::fromUtf8("Ε");
          else pla=QString::fromUtf8("ε");
          inserttextline(pla);
          break;
        case Qt::Key_Z:
          if (shiftkey) pla=QString::fromUtf8("Ζ");
          else pla=QString::fromUtf8("ζ");
          inserttextline(pla);
          break;
        case Qt::Key_Q:
          if (shiftkey) pla=QString::fromUtf8("Η");
          else pla=QString::fromUtf8("η");
          inserttextline(pla);
          break;
        case Qt::Key_H:
          if (shiftkey) pla=QString::fromUtf8("Θ");
          else pla=QString::fromUtf8("θ");
          inserttextline(pla);
          break;
        case Qt::Key_I:
          if (shiftkey) pla=QString::fromUtf8("Ι");
          else pla=QString::fromUtf8("ι");
          inserttextline(pla);
          break;
        case Qt::Key_K:
          if (shiftkey) pla=QString::fromUtf8("Κ");
          else pla=QString::fromUtf8("κ");
          inserttextline(pla);
          break;
        case Qt::Key_L:
          if (shiftkey) pla=QString::fromUtf8("Λ");
          else pla=QString::fromUtf8("λ");
          inserttextline(pla);
          break;
        case Qt::Key_M:
          if (shiftkey) pla=QString::fromUtf8("Μ");
          else pla=QString::fromUtf8("μ");
          inserttextline(pla);
          break;
        case Qt::Key_N:
          if (shiftkey) pla=QString::fromUtf8("Ν");
          else pla=QString::fromUtf8("ν");
          inserttextline(pla);
          break;
        case Qt::Key_X:
          if (shiftkey) pla=QString::fromUtf8("Ξ");
          else pla=QString::fromUtf8("ξ");
          inserttextline(pla);
          break;
        case Qt::Key_O:
          if (shiftkey) pla=QString::fromUtf8("Ο");
          else pla=QString::fromUtf8("ο");
          inserttextline(pla);
          break;
        case Qt::Key_P:
          if (shiftkey) pla=QString::fromUtf8("Π");
          else pla=QString::fromUtf8("π");
          inserttextline(pla);
          break;
        case Qt::Key_R:
          if (shiftkey) pla=QString::fromUtf8("Ρ");
          else pla=QString::fromUtf8("ρ");
          inserttextline(pla);
          break;
        case Qt::Key_S:
          if (shiftkey) pla=QString::fromUtf8("Σ");
          else pla=QString::fromUtf8("σ");
          inserttextline(pla);
          break;
        case Qt::Key_T:
          if (shiftkey) pla=QString::fromUtf8("Τ");
          else pla=QString::fromUtf8("τ");
          inserttextline(pla);
          break;
        case Qt::Key_Y:
          if (shiftkey) pla=QString::fromUtf8("Υ");
          else pla=QString::fromUtf8("υ");
          inserttextline(pla);
          break;
        case Qt::Key_F:
          if (shiftkey) pla=QString::fromUtf8("Φ");
          else pla=QString::fromUtf8("φ");
          inserttextline(pla);
          break;
        case Qt::Key_C:
          if (shiftkey) pla=QString::fromUtf8("Χ");
          else pla=QString::fromUtf8("χ");
          inserttextline(pla);
          break;
        case Qt::Key_U:
          if (shiftkey) pla=QString::fromUtf8("Ψ");
          else pla=QString::fromUtf8("ψ");
          inserttextline(pla);
          break;
        case Qt::Key_W:
          if (shiftkey) pla=QString::fromUtf8("Ω");
          else pla=QString::fromUtf8("ω");
          inserttextline(pla);
          break;
        case Qt::Key_J:
          if (shiftkey) pla=QString::fromUtf8("Ϳ");
          else pla=QString::fromUtf8("ϳ");
          inserttextline(pla);
          break;
        case Qt::Key_V:
          if (shiftkey) pla=QString::fromUtf8("Ͷ");
          else pla=QString::fromUtf8("ͷ");
          inserttextline(pla);
          break;
        default:
          altkey=false;
          m_AButton->setEnabled(altkey);
          QLineEdit::keyPressEvent( e);
          break;
      }
      if (hold_altkey==false)
        {
           altkey=false;
           cancel_altkey=false;
           m_AButton->setEnabled(altkey);
           myrepaintline();
        }
    }
      else QLineEdit::keyPressEvent( e);
  }
}

bool MyLineEdit::focusNextPrevChild(bool next)
{
  return false;
}

void MyLineEdit::keyReleaseEvent(QKeyEvent *e)
{
  if (e->key() == Qt::Key_Alt) {
  qDebug() << "Alt released";
  hold_altkey=false;
  if (cancel_altkey==true)
    {
      altkey=false;
      cancel_altkey=false;
      m_AButton->setEnabled(altkey);
      myrepaintline();
    }
   e->ignore();
  }
  else if (e->key() == Qt::Key_Shift) {
  qDebug() << "Shift released";
  hold_shiftkey=false;
  e->ignore();
  }
  else if (e->key() == Qt::Key_Control) {
  qDebug() << "Ctrl released";
  ctrlkey=false;
  e->ignore();
  }
  else
    QLineEdit::keyReleaseEvent( e);
}


class MyTextEdit : public QTextEdit
{

public:
explicit MyTextEdit(QWidget *parent = 0);
void mousePressEvent(QMouseEvent *e);
void mouseReleaseEvent(QMouseEvent *e);
void keyPressEvent(QKeyEvent * e);
void keyReleaseEvent(QKeyEvent * e);
};


MyTextEdit::MyTextEdit(QWidget *parent) : QTextEdit(parent)
{


}

static MyTextEdit *edit;

void MyTextEdit::mousePressEvent(QMouseEvent *event)
{
  qDebug() << "mouse pressed";
  if(event->button() == Qt::RightButton)
    {
      QString my_text = this->toPlainText();
      int length = my_text.length();
      if (length==0)
     {
      QKeyEvent *keyEvent = new QKeyEvent(QEvent::KeyPress, Qt::Key_Escape, Qt::NoModifier, QString(QChar(Qt::Key_Escape)));
        QApplication::sendEvent(this, (QEvent *)keyEvent);
     }
    }
    /*
    else if(event->button() == Qt::LeftButton)
    {
      //event->setAccepted(true);
      //MyLineEdit::rejected();
      QKeyEvent *keyEvent = new QKeyEvent(QEvent::KeyPress, Qt::Key_Enter, Qt::NoModifier, QString(QChar(Qt::Key_Enter)));
        QApplication::sendEvent(this, (QEvent *)keyEvent);
    }
    */
  QTextEdit::mousePressEvent( event);
}

void MyTextEdit::mouseReleaseEvent(QMouseEvent *event)
{
  qDebug() << "mouse release";
  QTextEdit::mouseReleaseEvent( event);
}



void MyTextEdit::keyPressEvent(QKeyEvent *e)
{
  bool shiftkey;

if ((!e->modifiers()) && (e->key()==Qt::Key_Return || e->key()==Qt::Key_Enter))
{
    qDebug() << "Enter pressed";
    //QTextEdit::keyPressEvent( e);
    edit->insertPlainText(QString::fromUtf8("\r\n"));
    switch (adjust)
    {
      case 0: edit->setAlignment(Qt::AlignLeft);
      break;
      case 1: edit->setAlignment(Qt::AlignRight);
      break;
      case 2: edit->setAlignment(Qt::AlignCenter);
      break;
      case 3: edit->setAlignment(Qt::AlignCenter);
      break;
    }
    edit->repaint();
}
else
{
if ((e->modifiers() & Qt::ControlModifier) && (e->key()==Qt::Key_Return || e->key()==Qt::Key_Enter)) //|| e->key()==Qt::Key_Space) )
    {
        qDebug() << "Ctrl-Enter pressed";
        m_OButton->animateClick();
        e->ignore();
    }
if (e->key() == Qt::Key_Alt) {
  qDebug() << "Alt pressed";

  myrepaint();
  altkey=!altkey;
  hold_altkey=true;
  m_AButton->setEnabled(altkey);
  e->ignore();
  }
 else if (e->key() == Qt::Key_Shift) {
  qDebug() << "Shift pressed";
  hold_shiftkey=true;
  e->ignore();
  }
  else if (e->key() == Qt::Key_Control) {
  qDebug() << "Ctrl pressed";
  ctrlkey=true;
  e->ignore();
  }
  else
  {

    KModifierKeyInfo info;
    hold_capslockkey = info.isKeyLocked(Qt::Key_CapsLock);
    if (((hold_capslockkey) && (!hold_shiftkey)) || ((!hold_capslockkey) && (hold_shiftkey))) shiftkey=true;
    else shiftkey=false;
    if (altkey)
    {
      switch (e->key())
      {
        case Qt::Key_8:
          pla=QString::fromUtf8("°");
          inserttext(pla);
          break;
        case Qt::Key_3:
          pla=QString::fromUtf8("³");
          inserttext(pla);
          break;
        case Qt::Key_2:
          pla=QString::fromUtf8("²");
          inserttext(pla);
          break;
        case Qt::Key_Minus:
          pla=QString::fromUtf8("±");
          inserttext(pla);
          break;
        case Qt::Key_Slash:
          pla=QString::fromUtf8("÷");
          inserttext(pla);
          break;
        case Qt::Key_Stop://|| e->key()==Qt::Key_Space) )

          pla=QString::fromUtf8("·");
          inserttext(pla);
          break;
        case Qt::Key_1:
          pla=QString::fromUtf8("½");
          inserttext(pla);
          break;
        case Qt::Key_4:
          pla=QString::fromUtf8("¼");
          inserttext(pla);
          break;
        case Qt::Key_5:
          pla=QString::fromUtf8("¾");
          inserttext(pla);
          break;
        case Qt::Key_0:
          pla=QString::fromUtf8("Ø");
          inserttext(pla);
          break;
        case Qt::Key_A:
          if (shiftkey) pla=QString::fromUtf8("Α");
          else pla=QString::fromUtf8("α");
          inserttext(pla);
          break;
        case Qt::Key_B:
          if (shiftkey) pla=QString::fromUtf8("Β");
          else pla=QString::fromUtf8("β");
          inserttext(pla);
          break;
        case Qt::Key_G:
          if (shiftkey) pla=QString::fromUtf8("Γ");
          else pla=QString::fromUtf8("γ");
          inserttext(pla);
          break;
        case Qt::Key_D:
          if (shiftkey) pla=QString::fromUtf8("Δ");
          else pla=QString::fromUtf8("δ");
          inserttext(pla);
          break;
        case Qt::Key_E:
          if (shiftkey) pla=QString::fromUtf8("Ε");
          else pla=QString::fromUtf8("ε");
          inserttext(pla);
          break;
        case Qt::Key_Z:
          if (shiftkey) pla=QString::fromUtf8("Ζ");
          else pla=QString::fromUtf8("ζ");
          inserttext(pla);
          break;
        case Qt::Key_Q:
          if (shiftkey) pla=QString::fromUtf8("Η");
          else pla=QString::fromUtf8("η");
          inserttext(pla);
          break;
        case Qt::Key_H:
          if (shiftkey) pla=QString::fromUtf8("Θ");
          else pla=QString::fromUtf8("θ");
          inserttext(pla);
          break;
        case Qt::Key_I:
          if (shiftkey) pla=QString::fromUtf8("Ι");
          else pla=QString::fromUtf8("ι");
          inserttext(pla);
          break;
        case Qt::Key_K:
          if (shiftkey) pla=QString::fromUtf8("Κ");
          else pla=QString::fromUtf8("κ");
          inserttext(pla);
          break;
        case Qt::Key_L:
          if (shiftkey) pla=QString::fromUtf8("Λ");
          else pla=QString::fromUtf8("λ");
          inserttext(pla);
          break;
        case Qt::Key_M:
          if (shiftkey) pla=QString::fromUtf8("Μ");
          else pla=QString::fromUtf8("μ");
          inserttext(pla);
          break;
        case Qt::Key_N:
          if (shiftkey) pla=QString::fromUtf8("Ν");
          else pla=QString::fromUtf8("ν");
          inserttext(pla);
          break;
        case Qt::Key_X:
          if (shiftkey) pla=QString::fromUtf8("Ξ");
          else pla=QString::fromUtf8("ξ");
          inserttext(pla);
          break;
        case Qt::Key_O:
          if (shiftkey) pla=QString::fromUtf8("Ο");
          else pla=QString::fromUtf8("ο");
          inserttext(pla);
          break;
        case Qt::Key_P:
          if (shiftkey) pla=QString::fromUtf8("Π");
          else pla=QString::fromUtf8("π");
          inserttext(pla);
          break;
        case Qt::Key_R:
          if (shiftkey) pla=QString::fromUtf8("Ρ");
          else pla=QString::fromUtf8("ρ");
          inserttext(pla);
          break;
        case Qt::Key_S:
          if (shiftkey) pla=QString::fromUtf8("Σ");
          else pla=QString::fromUtf8("σ");
          inserttext(pla);
          break;
        case Qt::Key_T:
          if (shiftkey) pla=QString::fromUtf8("Τ");
          else pla=QString::fromUtf8("τ");
          inserttext(pla);
          break;
        case Qt::Key_Y:
          if (shiftkey) pla=QString::fromUtf8("Υ");
          else pla=QString::fromUtf8("υ");
          inserttext(pla);
          break;
        case Qt::Key_F:
          if (shiftkey) pla=QString::fromUtf8("Φ");
          else pla=QString::fromUtf8("φ");
          inserttext(pla);
          break;
        case Qt::Key_C:
          if (shiftkey) pla=QString::fromUtf8("Χ");
          else pla=QString::fromUtf8("χ");
          inserttext(pla);
          break;
        case Qt::Key_U:
          if (shiftkey) pla=QString::fromUtf8("Ψ");
          else pla=QString::fromUtf8("ψ");
          inserttext(pla);
          break;
        case Qt::Key_W:
          if (shiftkey) pla=QString::fromUtf8("Ω");
          else pla=QString::fromUtf8("ω");
          inserttext(pla);
          break;
        case Qt::Key_J:
          if (shiftkey) pla=QString::fromUtf8("Ϳ");
          else pla=QString::fromUtf8("ϳ");
          inserttext(pla);
          break;
        case Qt::Key_V:
          if (shiftkey) pla=QString::fromUtf8("Ͷ");
          else pla=QString::fromUtf8("ͷ");
          inserttext(pla);
          break;
        default:
          altkey=false;
          m_AButton->setEnabled(altkey);
          QTextEdit::keyPressEvent( e);
          break;
      }
      if (hold_altkey==false)
        {
           altkey=false;
           cancel_altkey=false;
           m_AButton->setEnabled(altkey);
           //myrepaint();
        }
    }
      else QTextEdit::keyPressEvent( e);
  }
}
}

void MyTextEdit::keyReleaseEvent(QKeyEvent *e)
{
  /*
if ((!e->modifiers()) && (e->key()==Qt::Key_Return || e->key()==Qt::Key_Enter))
{
    qDebug() << "Enter release";
    switch (adjust)
    {
      case 0: edit->setAlignment(Qt::AlignLeft);
      break;
      case 1: edit->setAlignment(Qt::AlignRight);
      break;
      case 2: edit->setAlignment(Qt::AlignCenter);
      break;
      case 3: edit->setAlignment(Qt::AlignCenter);
      break;
    }
    QTextEdit::keyReleaseEvent( e);

}
else
  */
  if (e->key() == Qt::Key_Alt) {
  qDebug() << "Alt released";
  hold_altkey=false;
  if (cancel_altkey==true)
    {
      altkey=false;
      cancel_altkey=false;
      m_AButton->setEnabled(altkey);
      myrepaint();
    }
   e->ignore();
  }
  else if (e->key() == Qt::Key_Shift) {
  qDebug() << "Shift released";
  hold_shiftkey=false;
  e->ignore();
  }
  else if (e->key() == Qt::Key_Control) {
  qDebug() << "Ctrl released";
  ctrlkey=false;
  e->ignore();
  }
  else
    QTextEdit::keyReleaseEvent( e);
}


static QFont myfont;

//static MyTextEdit *edit;
static MyLineEdit *line_edit;

int global_height, global_width, global_posx, global_posy, global_reload, global_cursor_pos;

void set_global_cursor_pos(int pos)
{
  global_cursor_pos=pos;
}

int get_global_cursor_pos(void)
{
  return global_cursor_pos;
}

static void inserttext(QString pla)
{
   edit->insertPlainText(pla);
   cancel_altkey=true;
   if (!hold_altkey)
   {
      altkey=false;
      cancel_altkey=false;
      m_AButton->setEnabled(altkey);
      myrepaint();
   }
}

static void inserttextline(QString pla)
{
   line_edit->insert(pla);
   cancel_altkey=true;
   if (!hold_altkey)
   {
      altkey=false;
      cancel_altkey=false;
      m_AButton->setEnabled(altkey);
      myrepaintline();
   }
}

static void myrepaint()
{
  edit->repaint();
}

static void myrepaintline()
{
  line_edit->repaint();
}

static void onReload()
{
  global_reload=1;
}


static void onHidden()
{
  //edit->selectAll();

  hidden= (!hidden);
  if (hidden) palette->setColor(QPalette::Text,Qt::gray);
  else palette->setColor(QPalette::Text,Qt::white);
  edit->setPalette(*palette);
  edit->repaint();
  edit->setFocus();
}

static void onHiddenline()
{
  //line_edit->selectAll();

  hidden= (!hidden);
  if (hidden) palette->setColor(QPalette::Text,Qt::gray);
  else palette->setColor(QPalette::Text,Qt::white);
  line_edit->setPalette(*palette);
  line_edit->repaint();
  line_edit->setFocus();
}

static void onUnderlined()
{
  if (!myfont.underline())
    myfont.setUnderline(true);
  else
    myfont.setUnderline(false);
  edit->setFont(myfont);
  edit->repaint();
  edit->setFocus();
}

static void onUnderlinedline()
{
  if (!myfont.underline())
    myfont.setUnderline(true);
  else
    myfont.setUnderline(false);
  line_edit->setFont(myfont);
  line_edit->repaint();
  line_edit->setFocus();
}

static void onBold()
{
  if (!myfont.bold())
    myfont.setBold(true);
  else
    myfont.setBold(false);
  edit->setFont(myfont);
  edit->repaint();
  edit->setFocus();
}

static void onBoldline()
{
  if (!myfont.bold())
    myfont.setBold(true);
  else
    myfont.setBold(false);
  line_edit->setFont(myfont);
  line_edit->repaint();
  line_edit->setFocus();
}

static void onItalic()
{
   if (!myfont.italic())
    myfont.setItalic(true);
  else
    myfont.setItalic(false);
  edit->setFont(myfont);
  edit->repaint();
  edit->setFocus();
}

static void onItalicline()
{
   if (!myfont.italic())
    myfont.setItalic(true);
  else
    myfont.setItalic(false);
  line_edit->setFont(myfont);
  line_edit->repaint();
  line_edit->setFocus();
}

static void onAlignLeft()
{
  edit->selectAll();
  edit->setAlignment(Qt::AlignLeft); // | Qt::AlignBaseline);
  edit->repaint();
  QTextCursor cursor = edit->textCursor();
  cursor.movePosition( QTextCursor::End );
  edit->setTextCursor( cursor );
  VCenter=0;
  edit->setFocus();
  adjust=0;
}

static void onAlignLeftline()
{
  line_edit->selectAll();
  line_edit->setAlignment(Qt::AlignLeft | Qt::AlignBaseline);
  line_edit->repaint();
  //QTextCursor cursor = line_edit->textCursor();
  //cursor.movePosition( QTextCursor::End );
  //line_edit->setTextCursor( cursor );
  line_edit->end(false);
  line_edit->setFocus();
}


static void onAlignCenter()
{
  edit->selectAll();
  edit->setAlignment(Qt::AlignCenter); // | Qt::AlignBaseline);
  edit->repaint();
  QTextCursor cursor = edit->textCursor();
  cursor.movePosition( QTextCursor::End );
  edit->setTextCursor( cursor );
  VCenter=0;
  edit->setFocus();
  adjust=2;
}

static void onAlignCenterline()
{
  line_edit->selectAll();
  line_edit->setAlignment(Qt::AlignCenter | Qt::AlignBaseline);
  line_edit->repaint();
  //QTextCursor cursor = line_edit->textCursor();
  //cursor.movePosition( QTextCursor::End );
  //line_edit->setTextCursor( cursor );
  line_edit->end(false);
  line_edit->setFocus();
}

static void onAlignMiddleCenterline()
{
  line_edit->selectAll();
  line_edit->setAlignment(Qt::AlignCenter | Qt::AlignVCenter);
  line_edit->repaint();
  //QTextCursor cursor = line_edit->textCursor();
  //cursor.movePosition( QTextCursor::End );
  //line_edit->setTextCursor( cursor );
  line_edit->end(false);
  line_edit->setFocus();
}

static void onAlignRight()
{
  edit->selectAll();
  edit->setAlignment(Qt::AlignRight); // | Qt::AlignBaseline);
  edit->repaint();
  QTextCursor cursor = edit->textCursor();
  cursor.movePosition( QTextCursor::End );
  edit->setTextCursor( cursor );
  VCenter=0;
  edit->setFocus();
  adjust=1;
}

static void onAlignRightline()
{
  line_edit->selectAll();
  line_edit->setAlignment(Qt::AlignRight | Qt::AlignBaseline);
  line_edit->repaint();
  //QTextCursor cursor = line_edit->textCursor();
  //cursor.movePosition( QTextCursor::End );
  //line_edit->setTextCursor( cursor );
  line_edit->end(false);
  line_edit->setFocus();
}


static void addButtonBox(QDialog &dlg, QDialogButtonBox::StandardButtons buttons = QDialogButtonBox::Ok | QDialogButtonBox::Cancel)
{
    QDialogButtonBox *buttonBox = new QDialogButtonBox(buttons, &dlg);
    dlg.layout()->addWidget(buttonBox);
    QObject::connect(buttonBox, SIGNAL(accepted()), &dlg, SLOT(accept()));
    QObject::connect(buttonBox, SIGNAL(rejected()), &dlg, SLOT(reject()));
}

static void addButtonBoxEx(QDialog &dlg, QDialogButtonBox::StandardButtons buttons = QDialogButtonBox::Ok | QDialogButtonBox::Cancel)
{

    QDialogButtonBox *buttonBox = new QDialogButtonBox(&dlg);


    m_AButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);
    QPushButton *m_HButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);
    QPushButton *m_UButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);
    QPushButton *m_BButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);
    QPushButton *m_IButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);
    QPushButton *m_LButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);
    QPushButton *m_CButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);
    QPushButton *m_RButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);
    QPushButton *m_NButton = buttonBox->button(QDialogButtonBox::NoButton);
    m_EButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);  //Esc
    m_OButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);  //OK


    QPixmap Apixmap(QString::fromLatin1("./Bitmaps/Alt.png"));
    QIcon AButtonIcon(Apixmap);
    m_AButton->setIcon(AButtonIcon);

    m_AButton->setFixedSize( 32, 32 );
    m_AButton->setIconSize( QSize(26, 26) );
    m_AButton->show();
    m_AButton->setEnabled(false);

    QPixmap Hpixmap(QString::fromLatin1("./Bitmaps/hidden_text.png"));
    QIcon HButtonIcon(Hpixmap);
    m_HButton->setIcon(HButtonIcon);

    m_HButton->setFixedSize( 32, 32 );
    m_HButton->setIconSize( QSize(s32, s32) );
    m_HButton->show();
    m_HButton->setEnabled(true);

    QPixmap Upixmap(QString::fromLatin1("./Bitmaps/underlined.png"));
    QIcon UButtonIcon(Upixmap);
    m_UButton->setIcon(UButtonIcon);

    m_UButton->setFixedSize( 32, 32 );
    m_UButton->setIconSize( QSize(s32, s32) );
    m_UButton->show();
    m_UButton->setEnabled(true);

    QPixmap Bpixmap(QString::fromLatin1("./Bitmaps/bold.png"));
    QIcon BButtonIcon(Bpixmap);
    m_BButton->setIcon(BButtonIcon);
    m_BButton->setFixedSize( 32, 32 );
    m_BButton->setIconSize( QSize(s32, s32) );
    m_BButton->show();
    m_BButton->setEnabled(true);

    QPixmap Ipixmap(QString::fromLatin1("./Bitmaps/italic.png"));
    QIcon IButtonIcon(Ipixmap);
    m_IButton->setIcon(IButtonIcon);
    m_IButton->setFixedSize( 32, 32 );
    m_IButton->setIconSize( QSize(s32, s32) );
    m_IButton->show();
    m_IButton->setEnabled(true);

    QPixmap Lpixmap(QString::fromLatin1("./Bitmaps/align-left.png"));
    QIcon LButtonIcon(Lpixmap);
    m_LButton->setIcon(LButtonIcon);
    m_LButton->setFixedSize( 32, 32 );
    m_LButton->setIconSize( QSize(s32, s32) );
    m_LButton->show();
    m_LButton->setEnabled(true);

    QPixmap Cpixmap(QString::fromLatin1("./Bitmaps/align-center.png"));
    QIcon CButtonIcon(Cpixmap);
    m_CButton->setIcon(CButtonIcon);
    m_CButton->setFixedSize( 32, 32 );
    m_CButton->setIconSize( QSize(s32, s32) );
    m_CButton->show();
    m_CButton->setEnabled(true);

    QPixmap Rpixmap(QString::fromLatin1("./Bitmaps/align-right.png"));
    QIcon RButtonIcon(Rpixmap);
    m_RButton->setIcon(RButtonIcon);
    m_RButton->setFixedSize( 32, 32 );
    m_RButton->setIconSize( QSize(s32, s32) );
    m_RButton->show();
    m_RButton->setEnabled(true);


    QPixmap Epixmap(QString::fromLatin1("./Bitmaps/Esc.png")); //escape_d_48.png"));
    QIcon EButtonIcon(Epixmap);
    m_EButton->setIcon(EButtonIcon);
    m_EButton->setFixedSize( 32, 32 );
    m_EButton->setIconSize( QSize(32, 32) );
    m_EButton->show(); //setVisible(true);
    m_EButton->setEnabled(true);

    QPixmap Opixmap(QString::fromLatin1("./Bitmaps/enter128.png")); //ok_d_48.png"));
    QIcon OButtonIcon(Opixmap);
    m_OButton->setFixedSize( 64, 32 );
    m_OButton->setIconSize( QSize(64, 32) );
    m_OButton->setIcon(OButtonIcon);
    m_OButton->show(); //setVisible(true);
    m_OButton->setEnabled(true);


    dlg.layout()->addWidget(buttonBox);

    QObject::connect(m_HButton, &QPushButton::clicked,  &dlg, &onHidden);
    QObject::connect(m_UButton, &QPushButton::clicked,  &dlg, &onUnderlined);
    QObject::connect(m_BButton, &QPushButton::clicked,  &dlg, &onBold);
    QObject::connect(m_IButton, &QPushButton::clicked,  &dlg, &onItalic);
    QObject::connect(m_LButton, &QPushButton::clicked,  &dlg, &onAlignLeft);
    QObject::connect(m_CButton, &QPushButton::clicked,  &dlg, &onAlignCenter);
    QObject::connect(m_RButton, &QPushButton::clicked,  &dlg, &onAlignRight);
    QObject::connect(m_OButton, SIGNAL(clicked()), &dlg, SLOT(accept()));
    QObject::connect(m_EButton, SIGNAL(clicked()), &dlg, SLOT(reject()));
}

static void addButtonBoxExLine(QDialog &dlg, QDialogButtonBox::StandardButtons buttons = QDialogButtonBox::Ok | QDialogButtonBox::Cancel)
{

    QDialogButtonBox *buttonBox = new QDialogButtonBox(&dlg);


    m_AButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);
    QPushButton *m_HButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);
    QPushButton *m_UButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);
    QPushButton *m_BButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);
    QPushButton *m_IButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);
    QPushButton *m_LButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);
    QPushButton *m_CButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);
    QPushButton *m_MButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);
    QPushButton *m_RButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);
    QPushButton *m_NButton = buttonBox->button(QDialogButtonBox::NoButton);
    QPushButton *m_EButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);  //Esc

    m_OButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::ApplyRole);  //OK


    QPixmap Apixmap(QString::fromLatin1("./Bitmaps/Alt.png"));
    QIcon AButtonIcon(Apixmap);
    m_AButton->setIcon(AButtonIcon);

    m_AButton->setFixedSize( 32, 32 );
    m_AButton->setIconSize( QSize(26, 26) );
    m_AButton->show();
    m_AButton->setEnabled(false);


    QPixmap Hpixmap(QString::fromLatin1("./Bitmaps/hidden_text.png"));
    QIcon HButtonIcon(Hpixmap);
    m_HButton->setIcon(HButtonIcon);

    m_HButton->setFixedSize( 32, 32 );
    m_HButton->setIconSize( QSize(s32, s32) );
    m_HButton->show();
    m_HButton->setEnabled(true);


    QPixmap Upixmap(QString::fromLatin1("./Bitmaps/underlined.png"));
    QIcon UButtonIcon(Upixmap);
    m_UButton->setIcon(UButtonIcon);

    m_UButton->setFixedSize( 32, 32 );
    m_UButton->setIconSize( QSize(s32, s32) );
    m_UButton->show();
    m_UButton->setEnabled(true);

    QPixmap Bpixmap(QString::fromLatin1("./Bitmaps/bold.png"));
    QIcon BButtonIcon(Bpixmap);
    m_BButton->setIcon(BButtonIcon);
    m_BButton->setFixedSize( 32, 32 );
    m_BButton->setIconSize( QSize(s32, s32) );
    m_BButton->show();
    m_BButton->setEnabled(true);

    QPixmap Ipixmap(QString::fromLatin1("./Bitmaps/italic.png"));
    QIcon IButtonIcon(Ipixmap);
    m_IButton->setIcon(IButtonIcon);
    m_IButton->setFixedSize( 32, 32 );
    m_IButton->setIconSize( QSize(s32, s32) );
    m_IButton->show();
    m_IButton->setEnabled(true);

    QPixmap Lpixmap(QString::fromLatin1("./Bitmaps/text_align_baselineleft.png"));
    QIcon LButtonIcon(Lpixmap);
    m_LButton->setIcon(LButtonIcon);
    m_LButton->setFixedSize( 32, 32 );
    m_LButton->setIconSize( QSize(s32, s32) );
    m_LButton->show();
    m_LButton->setEnabled(true);

    QPixmap Cpixmap(QString::fromLatin1("./Bitmaps/text_align_baselinecenter.png"));
    QIcon CButtonIcon(Cpixmap);
    m_CButton->setIcon(CButtonIcon);
    m_CButton->setFixedSize( 32, 32 );
    m_CButton->setIconSize( QSize(s32, s32) );
    m_CButton->show();
    m_CButton->setEnabled(true);

    QPixmap Mpixmap(QString::fromLatin1("./Bitmaps/text_align_middlecenter.png"));
    QIcon MButtonIcon(Mpixmap);
    m_MButton->setIcon(MButtonIcon);
    m_MButton->setFixedSize( 32, 32 );
    m_MButton->setIconSize( QSize(s32, s32) );
    m_MButton->show();
    m_MButton->setEnabled(true);

    QPixmap Rpixmap(QString::fromLatin1("./Bitmaps/text_align_baselineright.png"));
    QIcon RButtonIcon(Rpixmap);
    m_RButton->setIcon(RButtonIcon);
    m_RButton->setFixedSize( 32, 32 );
    m_RButton->setIconSize( QSize(s32, s32) );
    m_RButton->show();
    m_RButton->setEnabled(true);


    QPixmap Epixmap(QString::fromLatin1("./Bitmaps/Esc.png")); //escape_d_48.png"));
    QIcon EButtonIcon(Epixmap);
    m_EButton->setIcon(EButtonIcon);
    m_EButton->setFixedSize( 32, 32 );
    m_EButton->setIconSize( QSize(32, 32) );
    m_EButton->show(); //setVisible(true);
    m_EButton->setEnabled(true);

    QPixmap Opixmap(QString::fromLatin1("./Bitmaps/enter128.png")); //ok_d_48.png"));
    QIcon OButtonIcon(Opixmap);
    m_OButton->setFixedSize( 64, 32 );
    m_OButton->setIconSize( QSize(64, 32) );
    m_OButton->setIcon(OButtonIcon);
    m_OButton->show(); //setVisible(true);
    m_OButton->setEnabled(true);


    dlg.layout()->addWidget(buttonBox);

    QObject::connect(m_HButton, &QPushButton::clicked,  &dlg, &onHiddenline);
    QObject::connect(m_UButton, &QPushButton::clicked,  &dlg, &onUnderlinedline);
    QObject::connect(m_BButton, &QPushButton::clicked,  &dlg, &onBoldline);
    QObject::connect(m_IButton, &QPushButton::clicked,  &dlg, &onItalicline);
    QObject::connect(m_LButton, &QPushButton::clicked,  &dlg, &onAlignLeftline);
    QObject::connect(m_CButton, &QPushButton::clicked,  &dlg, &onAlignCenterline);
    QObject::connect(m_MButton, &QPushButton::clicked,  &dlg, &onAlignMiddleCenterline);
    QObject::connect(m_RButton, &QPushButton::clicked,  &dlg, &onAlignRightline);
    QObject::connect(m_OButton, SIGNAL(clicked()), &dlg, SLOT(accept()));
    QObject::connect(m_EButton, SIGNAL(clicked()), &dlg, SLOT(reject()));
}


static void addButtonBoxExFile(QDialog &dlg, QDialogButtonBox::StandardButtons buttons = QDialogButtonBox::Ok | QDialogButtonBox::Cancel)
{
    QDialogButtonBox *buttonBox = new QDialogButtonBox(buttons, &dlg);

    QPushButton *m_RlButton = buttonBox->addButton(QObject::tr(""), QDialogButtonBox::AcceptRole);

    QPixmap Upixmap(QString::fromLatin1("./Bitmaps/refresh.png"));
    QIcon RButtonIcon(Upixmap);
    m_RlButton->setIcon(RButtonIcon);
    m_RlButton->show();
    m_RlButton->setEnabled(true);


    dlg.layout()->addWidget(buttonBox);

    QObject::connect(m_RlButton, &QPushButton::clicked,  &dlg, &onReload);
    QObject::connect(buttonBox, SIGNAL(accepted()), &dlg, SLOT(accept()));
    QObject::connect(buttonBox, SIGNAL(rejected()), &dlg, SLOT(reject()));
}


static void addButtonBox__(QDialog &dlg, QDialogButtonBox::StandardButtons buttons = QDialogButtonBox::Ok | QDialogButtonBox::Cancel)
{
    auto buttonBox = new QDialogButtonBox(buttons, &dlg);
    dlg.layout()->addWidget(buttonBox);
    QObject::connect(buttonBox, &QDialogButtonBox::accepted, &dlg, &QDialog::accept);
    QObject::connect(buttonBox, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);
}

bool Widgets::inputBox(QWidget *parent, const QString &title, const QString &text, const QString &init, QString &result)
{
    QInputDialog dlg(parent);
    dlg.setWindowTitle(title);
    dlg.setLabelText(text);
    dlg.setTextValue(init);

    dlg.setWindowFlags(Qt::WindowStaysOnTopHint | Qt::FramelessWindowHint);
    //dlg.setWindowFlags(Qt::FramelessWindowHint);
    //dlg.setOption(QInputDialog::NoButtons);

    Utils::handleXGeometry(&dlg);

    bool retcode = (dlg.exec() == QDialog::Accepted);
    if (retcode) {
        result = dlg.textValue();
    }
    return retcode;
}

bool Widgets::passwordBox(QWidget *parent, const QString &title, const QString &text, QString &result)
{
    KPasswordDialog dlg(parent);
    dlg.setWindowTitle(title);
    dlg.setPrompt(text);

    Utils::handleXGeometry(&dlg);

    bool retcode = (dlg.exec() == QDialog::Accepted);
    if (retcode) {
        result = dlg.password();
    }
    return retcode;
}

bool Widgets::newPasswordBox(QWidget *parent, const QString &title, const QString &text, QString &result)
{
    KNewPasswordDialog dlg(parent);
    dlg.setWindowTitle(title);
    dlg.setPrompt(text);

    Utils::handleXGeometry(&dlg);

    bool retcode = (dlg.exec() == QDialog::Accepted);
    if (retcode) {
        result = dlg.password();
    }
    return retcode;
}


int Widgets::textBox(QWidget *parent, int width, int height, const QString &title, const QString &file)
{
  int ret;

    QDialog dlg(parent);
    dlg.setWindowTitle(title);
    dlg.setWindowFlags(Qt::WindowStaysOnTopHint);

    auto mainLayout = new QVBoxLayout(&dlg);

    auto edit = new KTextEdit(&dlg);

    mainLayout->addWidget(edit);

    edit->setReadOnly(true);
    edit->setFocus();

    //addButtonBox(dlg, QDialogButtonBox::Esc);
    addButtonBox(dlg);


    if (file == QLatin1String("-")) {
        QTextStream s(stdin, QIODevice::ReadOnly);
        while (!s.atEnd()) {
            edit->append(s.readLine());
        }
    } else {
        QFile f(file);
        if (!f.open(QIODevice::ReadOnly)) {
            qWarning() << i18n("kdialog: could not open file %1", file);
            return -1;
        }
        QTextStream s(&f);
        while (!s.atEnd()) {
            edit->append(s.readLine());
        }
    }

    edit->setTextCursor(QTextCursor(edit->document()));

    if (width > 0 && height > 0) {
        dlg.resize(QSize(width, height));
    }

    Utils::handleXGeometry(&dlg);
    dlg.setWindowTitle(title);

    ret = dlg.exec();


    return (ret == QDialog::Accepted) ? 0 : 1;
}

int Widgets::imgBox(QWidget *parent, const QString &title, const QString &file)
{
    QDialog dlg(parent);
    dlg.setWindowTitle(title);

    auto mainLayout = new QVBoxLayout(&dlg);

    auto label = new QLabel(&dlg);
    mainLayout->addWidget(label);

    addButtonBox(dlg, QDialogButtonBox::Ok);

    QFile f(file);
    if (!f.open(QIODevice::ReadOnly)) {
        qWarning() << i18n("kdialog: could not open file %1", file);
        return -1;
    }

    label->setPixmap(QPixmap(file));
    Utils::handleXGeometry(&dlg);
    return (dlg.exec() == QDialog::Accepted) ? 0 : 1;
}

int Widgets::imgInputBox(QWidget *parent, const QString &title, const QString &file, const QString &text, QString &result)
{
    QFile f(file);
    if (!f.open(QIODevice::ReadOnly)) {
        qWarning() << i18n("kdialog: could not open file %1", file);
        return -1;
    }

    QDialog dlg(parent);
    dlg.setWindowTitle(title);

    auto mainLayout = new QVBoxLayout(&dlg);

    if (!text.isEmpty()) {
        auto head = new QLabel(&dlg);
        head->setText(text);
        mainLayout->addWidget(head);
    }

    auto label = new QLabel(&dlg);
    mainLayout->addWidget(label);

    label->setPixmap(QPixmap(file));

    auto edit = new QLineEdit(&dlg);
    mainLayout->addWidget(edit);
    edit->setReadOnly(false);
    edit->setFocus();

    addButtonBox(dlg, QDialogButtonBox::Ok);
    Utils::handleXGeometry(&dlg);

    bool retcode = (dlg.exec() == QDialog::Accepted);

    if (retcode) {
        result = edit->text();
    }

    return retcode;
}

int Widgets::textInputBox___(QWidget *parent, int width, int height, const QString &title, const QString &text, const QString &init, QString &result)
{
    QDialog dlg(parent);
    dlg.setWindowTitle(title);
    auto mainLayout = new QVBoxLayout(&dlg);

    if (!text.isEmpty()) {
        auto label = new QLabel(&dlg);
        mainLayout->addWidget(label);
        label->setText(text);
    }

    auto edit = new KTextEdit(&dlg);
    mainLayout->addWidget(edit);
    edit->setReadOnly(false);
    edit->setFocus();
    edit->insertPlainText(init);

    addButtonBox(dlg, QDialogButtonBox::Ok);

    if (width > 0 && height > 0) {
        dlg.resize(QSize(width, height));
    }

    Utils::handleXGeometry(&dlg);
    dlg.setWindowTitle(title);
    const int returnDialogCode = dlg.exec();
    result = edit->toPlainText();
    return returnDialogCode == QDialog::Accepted ? 0 : 1;
}


int Widgets::textInputBox(QWidget *parent, int width, int height, const QString& title, const QString& text, const QString& init, QString &result, const QString &fontface, const QString &fontfile, const QString &fontsize, const QString &fontwidth, const QString &etype, const QString &params)
{
    QDialog dlg(parent);
    //int x, y, cp;

    dlg.setWindowTitle(title);
    //int hint = (Qt::CustomizeWindowHint & ~Qt::WindowMinimizeButtonHint);
    ////int hint = (Qt::WindowTitleHint & ~Qt::WindowMinimizeButtonHint);
    ////dlg.setWindowFlags(static_cast<QFlag>(Qt::WindowStaysOnTopHint | hint));

    int newBorderWidth=5;
    //dlg.layout()->setContentsMargins( QMargins(5,5,5,5));  //newBorderWidth
    NcFramelessHelper *mFh = new NcFramelessHelper;
    mFh->setWidgetMovable( true );
    mFh->setWidgetResizable( true );
    mFh->setBorderWidth(newBorderWidth);
    mFh->activateOn( &dlg );
    dlg.setWindowFlags(Qt::WindowStaysOnTopHint | Qt::CustomizeWindowHint);

    QPixmap alfapixmap(QString::fromLatin1("./AlfaCad.png"));
    dlg.setWindowIcon(QIcon(alfapixmap));

    QVBoxLayout *mainLayout = new QVBoxLayout(&dlg);
    int pre_return;

    if (!text.isEmpty()) {
        QLabel *label = new QLabel(&dlg);
        mainLayout->addWidget(label);
        label->setText(text);
        label->setWordWrap(false);
    }

    edit = new MyTextEdit(&dlg);
    mainLayout->addWidget(edit);
    edit->setReadOnly(false);
    edit->setFocus();
    edit->insertPlainText(init);

    edit->setLineWrapMode(QTextEdit::NoWrap);

    //if (single)
   // {
      //edit->QTextDocument::maximumBlockCount=1;
    //  edit->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    //  edit->setFixedHeight(fontsize.toInt()+2);
    //}

    edit->setWindowIcon(QIcon(alfapixmap));

    edit->moveCursor(QTextCursor::Start, QTextCursor::MoveAnchor);

    QTextCursor curs = edit->textCursor(); //copies current cursor


    std::cerr << " setPosition:" << global_cursor_pos << "  " << std::endl;

    curs.setPosition(global_cursor_pos, QTextCursor::MoveAnchor);


    edit->setTextCursor(curs);


    QFontDatabase fontDatabase;
    int id = fontDatabase.addApplicationFont(QString::fromLatin1(fontfile.toLocal8Bit()));


    QString font_name=fontface;
    myfont.setFamily(font_name);

    int HEIGHT=fontsize.toInt();
    int WIDTH=fontwidth.toInt();
    int STRETCH=(int) ((((float)WIDTH/(float)HEIGHT)*1.9)*100.0);

    std::cerr << " Face:" << qPrintable(font_name) << "  Height:" << HEIGHT << " Width:" << WIDTH << "  Stretch:" << STRETCH << "  " << std::endl;

    myfont.setPixelSize(HEIGHT);
    myfont.setStretch(STRETCH);

    int fontparams=params.toInt();
    bool bold = (bool)((fontparams & 2)/2);
    bool italics = (bool)((fontparams & 4)/4);
    bool underline = (bool)((fontparams & 8)/8);
    adjust = (int)((fontparams & 48)/16);
    hidden = (bool)((fontparams & 64)/64);

    if( etype == QLatin1String("FILE"))
    {
      bold=false;
      italics=false;
      underline=false;
      adjust=0;
      hidden=false;
    }


    myfont.setBold(bold);
    myfont.setUnderline(underline);
    myfont.setItalic(italics);


    if (hidden)
    {
       palette->setColor(QPalette::Text,Qt::gray);
    }
    else palette->setColor(QPalette::Text,Qt::white);

    edit->setPalette(*palette);

    edit->setFont(myfont);

    switch (adjust)
    {
      case 0:
         //edit->setAlignment(Qt::AlignLeft);// | Qt::AlignBaseline);
         onAlignLeft();
         break;
      case 1:
         //edit->setAlignment(Qt::AlignRight); // | Qt::AlignBaseline);
         onAlignRight();
         break;
      case 2:
        //dit->setAlignment(Qt::AlignCenter); // | Qt::AlignBaseline);
        onAlignCenter();
        VCenter=0;
        break;
      case 3:
        //edit->setAlignment(Qt::AlignCenter | Qt::AlignVCenter);
        //edit->setAlignment(Qt::AlignCenter); // | Qt::AlignBaseline);
        onAlignCenter();
        VCenter=1;
        break;
      default:
        //edit->setAlignment(Qt::AlignLeft); // | Qt::AlignBaseline);
        onAlignLeft();
         break;
    }


    if( etype == QLatin1String("FILE")) addButtonBoxExFile(dlg);
    else addButtonBoxEx(dlg);

    global_reload=0;

    if (width > 0 && height > 0)
        dlg.resize(QSize(width, height));

    Utils::handleXGeometry(&dlg);

    dlg.setWindowTitle(title);



    QCursor::setPos ( dlg.pos().x() + width/2, dlg.pos().y() + height/2);

    //edit->selectAll();
    //edit->repaint();
    //QTextCursor cursor = edit->textCursor();
    //cursor.movePosition( QTextCursor::End );
    //edit->setTextCursor( cursor );


    const int returnDialogCode = dlg.exec();
    result = edit->toPlainText();
    pre_return=(returnDialogCode == QDialog::Accepted ? 0 : 1);
    if (pre_return==1)
    {
      std::cerr << "ESC" << std::endl;
      return 0;
    }

    int new_adjust;

    if (edit->alignment()==(Qt::AlignLeft)) /* | Qt::AlignBaseline))*/ new_adjust=0;
    else if (edit->alignment()==(Qt::AlignRight)) /*| Qt::AlignBaseline))*/ new_adjust=1;
    else if (edit->alignment()==(Qt::AlignCenter)) /* | Qt::AlignBaseline))*/
    {
      if (VCenter==0) new_adjust=2;
      else new_adjust=3;
    }
    //else if (edit->alignment()==(Qt::AlignCenter | Qt::AlignVCenter)) new_adjust=3;
    else  new_adjust=0;

    pre_return = 1 + myfont.bold() * 2 + myfont.italic() * 4 + myfont.underline() * 8 + new_adjust * 16 + hidden * 64 + global_reload*128;

    QTextCursor curs1 = edit->textCursor();

    //geometry
    global_width=dlg.width();
    global_height=dlg.height();
    global_posx=dlg.pos().x();
    global_posy=dlg.pos().y();
    global_cursor_pos=curs1.position();
    std::cerr << "global_cursor_pos:" << global_cursor_pos << "   " << std::endl;

    return pre_return;
}


int Widgets::InputBox(QWidget *parent, int width, int height, const QString& title, const QString& text, const QString& init, QString &result, const QString &fontface, const QString &fontfile, const QString &fontsize, const QString &fontwidth, const QString &etype, const QString &params)
{
    QDialog dlg(parent);
    //int x, y, cp;

    dlg.setWindowTitle(title);
    //dlg.setWindowFlags(Qt::WindowStaysOnTopHint | Qt::CustomizeWindowHint);

    QPixmap alfapixmap(QString::fromLatin1("./AlfaCad.png"));
    dlg.setWindowIcon(QIcon(alfapixmap));

    QVBoxLayout *mainLayout = new QVBoxLayout(&dlg);
    int pre_return;

    if (!text.isEmpty()) {
        QLabel *label = new QLabel(&dlg);
        mainLayout->addWidget(label);
        label->setText(text);
        label->setWordWrap(false);
    }

    line_edit = new MyLineEdit(&dlg);

    int newBorderWidth=5;

    dlg.layout()->setContentsMargins( QMargins(5,5,5,5));  //newBorderWidth
    //dlg.adjustSize();


    NcFramelessHelper *mFh = new NcFramelessHelper;
    mFh->setWidgetMovable( true );
    mFh->setWidgetResizable( true );
    //mFh->activateOn( (QWidget*)&dlg );  //line_edit
    mFh->setBorderWidth(newBorderWidth);
    mFh->activateOn( &dlg );  //line_edit

    /*
    Qt::WindowFlags flags = dlg.windowFlags();
    flags |= Qt::CustomizeWindowHint;
    flags &= ~Qt::WindowContextHelpButtonHint;
    flags &= ~Qt::WindowSystemMenuHint;
    flags &= ~Qt::WindowMinMaxButtonsHint;
    flags &= ~Qt::WindowMinimizeButtonHint;
    flags &= ~Qt::WindowMaximizeButtonHint;
    flags &= ~Qt::WindowCloseButtonHint;
    */

    dlg.setWindowFlags(Qt::WindowStaysOnTopHint | Qt::CustomizeWindowHint);
    ////dlg.setWindowFlags(flags);

    //dlg.setFixedHeight(dlg.height());


    mainLayout->addWidget(line_edit);
    line_edit->setReadOnly(false);
    line_edit->setFocus();
    //line_edit->insertPlainText(init);
    line_edit->insert(init);

    //line_edit->setLineWrapMode(QTextEdit::NoWrap);

    line_edit->setWindowIcon(QIcon(alfapixmap));

    ////line_edit->moveCursor(QTextCursor::Start, QTextCursor::MoveAnchor);
    line_edit->home(false);

    ////QTextCursor curs = line_edit->textCursor(); //copies current cursor


    std::cerr << " setPosition:" << global_cursor_pos << "  " << std::endl;

    ////curs.setPosition(global_cursor_pos, QTextCursor::MoveAnchor);
    line_edit->setCursorPosition(global_cursor_pos);


    ////line_edit->setTextCursor(curs);


    QFontDatabase fontDatabase;
    int id = fontDatabase.addApplicationFont(QString::fromLatin1(fontfile.toLocal8Bit()));


    QString font_name=fontface;
    myfont.setFamily(font_name);

    int HEIGHT=fontsize.toInt();
    int WIDTH=fontwidth.toInt();
    int STRETCH=(int) ((((float)WIDTH/(float)HEIGHT)*1.9)*100.0);

    std::cerr << " Face:" << qPrintable(font_name) << "  Height:" << HEIGHT << " Width:" << WIDTH << "  Stretch:" << STRETCH << "  " << std::endl;

    myfont.setPixelSize(HEIGHT);
    myfont.setStretch(STRETCH);

    int fontparams=params.toInt();
    bool bold = (bool)((fontparams & 2)/2);
    bool italics = (bool)((fontparams & 4)/4);
    bool underline = (bool)((fontparams & 8)/8);
    int adjust_line = (int)((fontparams & 48)/16);
    hidden = (bool)((fontparams & 64)/64);

    if( etype == QLatin1String("FILE"))
    {
      bold=false;
      italics=false;
      underline=false;
      adjust_line=0;
      hidden=false;
    }


    myfont.setBold(bold);
    myfont.setUnderline(underline);
    myfont.setItalic(italics);


    if (hidden)
    {
       palette->setColor(QPalette::Text,Qt::gray);
    }
    else palette->setColor(QPalette::Text,Qt::white);

    line_edit->setPalette(*palette);

    line_edit->setFont(myfont);

    switch (adjust_line)
    {
      case 0:
         //line_edit->setAlignment(Qt::AlignLeft | Qt::AlignBaseline);
         onAlignLeftline();
         break;
      case 1:
         //line_edit->setAlignment(Qt::AlignRight | Qt::AlignBaseline);
         onAlignRightline();
         break;
      case 2:
        //line_edit->setAlignment(Qt::AlignCenter | Qt::AlignBaseline);
        onAlignCenterline();
        break;
      case 3:
        //line_edit->setAlignment(Qt::AlignCenter | Qt::AlignVCenter);
        onAlignMiddleCenterline();
        break;
      default:
        //line_edit->setAlignment(Qt::AlignLeft | Qt::AlignBaseline);
        onAlignLeftline();
         break;
    }


    //if( etype == QLatin1String("FILE")) addButtonBoxExFile(dlg);
    //else
    addButtonBoxExLine(dlg);

    global_reload=0;

    if (width > 0 && height > 0)
        dlg.resize(QSize(width, height));

    Utils::handleXGeometry(&dlg);

     dlg.setFixedHeight(dlg.height());


    dlg.setWindowTitle(title);

    QCursor::setPos ( dlg.pos().x() + width/2, dlg.pos().y() + height/2);

    const int returnDialogCode = dlg.exec();

    qDebug() << "returnDialogCode" << returnDialogCode;
    ////result = line_edit->toPlainText();
    result = line_edit->text();
    qDebug() << "result" << result;
    pre_return=(returnDialogCode == QDialog::Accepted ? 0 : 1);
    if (pre_return==0)
    {
      if (ret_line==-1)
      {
        std::cerr << "TAB" << std::endl;
        qDebug() << "TAB";
        return -1;
      }
    }
    else
    {
      std::cerr << "ESC" << std::endl;
      return 0;
    }


    int new_adjust;

    if (line_edit->alignment()==(Qt::AlignLeft | Qt::AlignBaseline)) new_adjust=0;
    else if (line_edit->alignment()==(Qt::AlignRight | Qt::AlignBaseline)) new_adjust=1;
    else if (line_edit->alignment()==(Qt::AlignCenter | Qt::AlignBaseline)) new_adjust=2;
    else if (line_edit->alignment()==(Qt::AlignCenter | Qt::AlignVCenter)) new_adjust=3;
    else  new_adjust=0;


    pre_return = 1 + myfont.bold() * 2 + myfont.italic() * 4 + myfont.underline() * 8 + new_adjust * 16 + hidden * 64 + global_reload*128;

    ////QTextCursor curs1 = line_edit->textCursor();

    //geometry
    global_width=dlg.width();
    global_height=dlg.height();
    global_posx=dlg.pos().x();
    global_posy=dlg.pos().y();
    global_cursor_pos=line_edit->cursorPosition();
    std::cerr << "global_cursor_pos:" << global_cursor_pos << "   " << std::endl;

    std::cerr << "pre_return:" << pre_return << "   " << std::endl;

    return pre_return;
}

bool Widgets::comboBox(QWidget *parent, const QString &title, const QString &text, const QStringList &args, const QString &defaultEntry, QString &result)
{
    QDialog dlg(parent);
    dlg.setWindowTitle(title);

    auto mainLayout = new QVBoxLayout(&dlg);

    auto label = new QLabel(&dlg);
    label->setText(text);
    mainLayout->addWidget(label);
    auto combo = new QComboBox(&dlg);
    combo->addItems(args);
    combo->setCurrentIndex(combo->findText(defaultEntry));
    combo->setFocus();
    mainLayout->addWidget(combo);
    addButtonBox(dlg);
    Utils::handleXGeometry(&dlg);

    bool retcode = (dlg.exec() == QDialog::Accepted);

    if (retcode) {
        result = combo->currentText();
    }

    return retcode;
}

bool Widgets::listBox(QWidget *parent, const QString &title, const QString &text, const QStringList &args, const QString &defaultEntry, QString &result)
{
    KListBoxDialog box(text, parent);

    box.setWindowTitle(title);

    for (int i = 0; i+1 < args.count(); i += 2) {
        box.insertItem(args[i+1]);
    }
    box.setCurrentItem(defaultEntry);

    Utils::handleXGeometry(&box);

    const bool retcode = (box.exec() == QDialog::Accepted);
    if (retcode) {
        result = args[ box.currentItem()*2 ];
    }
    return retcode;
}

bool Widgets::checkList(QWidget *parent, const QString &title, const QString &text, const QStringList &args, bool separateOutput, QStringList &result)
{
    QStringList entries, tags;

    result.clear();

    KListBoxDialog box(text, parent);

    QListWidget &table = box.getTable();

    box.setWindowTitle(title);

    for (int i = 0; i+2 < args.count(); i += 3) {
        tags.append(args[i]);
        entries.append(args[i+1]);
    }

    table.addItems(entries);
    table.setSelectionMode(QListWidget::MultiSelection);
    table.setCurrentItem(nullptr); // This is to circumvent a Qt bug

    for (int i = 0; i+2 < args.count(); i += 3) {
        table.item(i/3)->setSelected(args[i+2] == QLatin1String("on"));
    }

    Utils::handleXGeometry(&box);

    const bool retcode = (box.exec() == QDialog::Accepted);

    if (retcode) {
        if (separateOutput) {
            for (int i = 0; i < table.count(); i++) {
                if (table.item(i)->isSelected()) {
                    result.append(tags[i]);
                }
            }
        } else {
            QString rs;
            for (int i = 0; i < table.count(); i++) {
                if (table.item(i)->isSelected()) {
                    rs += QLatin1String("\"") + tags[i] + QLatin1String("\" ");
                }
            }
            result.append(rs);
        }
    }
    return retcode;
}

bool Widgets::radioBox(QWidget *parent, const QString &title, const QString &text, const QStringList &args, QString &result)
{
    QStringList entries, tags;

    KListBoxDialog box(text, parent);

    QListWidget &table = box.getTable();

    box.setWindowTitle(title);

    for (int i = 0; i+2 < args.count(); i += 3) {
        tags.append(args[i]);
        entries.append(args[i+1]);
    }

    table.addItems(entries);

    for (int i = 0; i+2 < args.count(); i += 3) {
        if (args[i+2] == QLatin1String("on")) {
            table.setCurrentRow(i/3);
        }
    }

    Utils::handleXGeometry(&box);

    const bool retcode = (box.exec() == QDialog::Accepted);
    if (retcode) {
        result = tags[ table.currentRow() ];
    }
    return retcode;
}

bool Widgets::slider(QWidget *parent, const QString &title, const QString &text, int minValue, int maxValue, int step, int &result)
{
    QDialog dlg(parent);
    dlg.setWindowTitle(title);

    auto mainLayout = new QVBoxLayout(&dlg);

    auto label = new QLabel(&dlg);
    mainLayout->addWidget(label);
    label->setText(text);
    auto slider = new QSlider(&dlg);
    mainLayout->addWidget(slider);
    slider->setMinimum(minValue);
    slider->setMaximum(maxValue);
    slider->setSingleStep(step);
    slider->setTickInterval(step);
    slider->setTickPosition(QSlider::TicksAbove);
    slider->setOrientation(Qt::Horizontal);
    slider->setFocus();
    Utils::handleXGeometry(&dlg);

    addButtonBox(dlg);

    Utils::handleXGeometry(&dlg);
    const bool retcode = (dlg.exec() == QDialog::Accepted);

    if (retcode) {
        result = slider->value();
    }

    return retcode;
}

bool Widgets::calendar(QWidget *parent, const QString &title, const QString &text, QDate &result, QDate defaultEntry)
{
    QDialog dlg(parent);
    dlg.setWindowTitle(title);

    auto mainLayout = new QVBoxLayout(&dlg);

    auto label = new QLabel(&dlg);
    mainLayout->addWidget(label);
    label->setText(text);
    auto dateWidget = new KDatePicker(defaultEntry, &dlg);
    mainLayout->addWidget(dateWidget);
    dateWidget->setFocus();
    addButtonBox(dlg);
    Utils::handleXGeometry(&dlg);

    const bool retcode = (dlg.exec() == QDialog::Accepted);

    if (retcode) {
        result = dateWidget->date();
    }

    return retcode;
}
