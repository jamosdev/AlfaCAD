#! /usr/bin/env bash
$XGETTEXT *.cpp -o $podir/kdialog.pot 
