KDialog allows you to display dialog boxes from shell scripts.

The syntax is very much inspired from the "dialog" command (which shows text mode dialogs).

However the width and height attributes have been removed for most dialogs - Qt/KDE have layouts ;)

A tutorial on using kdialog is available at <https://develop.kde.org/docs/administration/kdialog/>
