#ifndef		__DEMO_MUSIC_PLAYER_H__
#define		__DEMO_MUSIC_PLAYER_H__

void play_music(int id, int loop);
void stop_music(void);
void play_sound(int id, int vol, int pan, int freq, int loop);

#endif				/* __DEMO_MUSIC_PLAYER_H__ */
