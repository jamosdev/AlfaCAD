#ifndef		__DEMO_OGL_FLIPPING_H__
#define		__DEMO_OGL_FLIPPING_H__

#include "updtedvr.h"

extern void select_ogl_flipping(DEMO_SCREEN_UPDATE_DRIVER *driver);

#endif				/* __DEMO_OGL_FLIPPING_H__ */
