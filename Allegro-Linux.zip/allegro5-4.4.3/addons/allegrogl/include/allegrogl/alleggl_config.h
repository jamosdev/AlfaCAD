/* Define if the Mesa generic driver must be built. */
/* #undef ALLEGROGL_GENERIC_DRIVER */

/* Define if glXGetProcAddress must be appended by ARB. */
/* #undef ALLEGROGL_GLXGETPROCADDRESSARB */

/* Define if dynamic linking is supported. */
#define ALLEGROGL_HAVE_DYNAMIC_LINK

/* Define if XF86VidMode extension is supported. */
#define ALLEGROGL_HAVE_XF86VIDMODE
