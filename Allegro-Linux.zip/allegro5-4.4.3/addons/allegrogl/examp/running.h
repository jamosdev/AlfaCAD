/* Allegro datafile object indexes, produced by dat v3.9.38 (CVS), MSVC */
/* Datafile: running.dat */
/* Date: Fri Jul 20 17:03:17 2001 */
/* Do not hand edit! */

#define FRAME_00_BMP                     0        /* BMP  */
#define FRAME_01_BMP                     1        /* BMP  */
#define FRAME_02_BMP                     2        /* BMP  */
#define FRAME_03_BMP                     3        /* BMP  */
#define FRAME_04_BMP                     4        /* BMP  */
#define FRAME_05_BMP                     5        /* BMP  */
#define FRAME_06_BMP                     6        /* BMP  */
#define FRAME_07_BMP                     7        /* BMP  */
#define FRAME_08_BMP                     8        /* BMP  */
#define FRAME_09_BMP                     9        /* BMP  */

