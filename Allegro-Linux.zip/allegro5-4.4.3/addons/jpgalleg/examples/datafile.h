/* Allegro datafile object indexes, produced by grabber v4.1.12 (CVS), MacOS X */
/* Datafile: /Users/lillo/projects/jpgalleg/examples/datafile.dat */
/* Date: Mon Jun 30 15:54:05 2003 */
/* Do not hand edit! */

#define JPGALLEG_LOGO                    0        /* JPEG */

