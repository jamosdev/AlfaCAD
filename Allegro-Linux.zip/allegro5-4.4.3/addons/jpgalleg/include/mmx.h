/* #undef JPGALLEG_MMX */
