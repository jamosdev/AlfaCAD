#ifndef MAKESCI_H
#define MAKESCI_H

int write_scite(char *filename, char *src);

#endif
