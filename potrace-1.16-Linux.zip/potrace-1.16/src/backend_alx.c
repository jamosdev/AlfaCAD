/* Copyright (C) 2001-2019 Peter Selinger.
   This file is part of Potrace. It is free software and it is covered
   by the GNU General Public License. See the file COPYING for details.
   Then developed by Marek Ratajczak
   */

/* The DXF backend of Potrace. */
#define LINUX


#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include <math.h>

#ifndef LINUX
#include<io.h>
#include<dos.h>
#include <stdint.h>
#else
#include <unistd.h>
#endif

#include "main.h"
#include "backend_alx.h"
#include "potracelib.h"
#include "lists.h"
#include "auxiliary.h"
#include "trans.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define Pi2 (2*3.1415926535897931)
#define OZero 1.0E-6

#define Max_Spec_Name 32
#define Max_Spec_Block 127
#define B3 4
#define VERB_LEN        12
#define VERB4_1         "ALFACAD4.1B"
#define NumSplinePoints 256 //8

#define BOOL bool

#define MAXPATH   260
#define MAXDRIVE  3
#define MAXDIR	  256
#define MAXFILE   256
#define MAXEXT	  255

#define WILDCARDS 0x01
#define EXTENSION 0x02
#define FILENAME  0x04
#define DIRECTORY 0x08
#define DRIVE	  0x10

typedef enum {FALSE = 0, TRUE} boolean;

enum ATRYBUT { ANieOkreslony=-1,Anormalny = 0,Ausuniety = 1,Ablok = 2, Aoblok = 3, Abad = 4,
    Apoblok = 5, Appoblok = 6, Apppoblok = 7 };

enum ExportBlockFlags {EBF_Old = 0x01, EBF_IP = 0x02 } ;
enum OBIEKT { ONoInDimBlock = -3, ONoInBlock = -2, ONieOkreslony= - 1, Olinia = 1, Otekst = 2,
    Oluk = 3,Ookrag = 4,Okolo = 5, Owwielokat = 6, Opoint = 7, OdBLOK = 8,
    Olinia3D = 9, Otekst3D = 10, Oluk3D = 11, Ookrag3D = 12, Ospline = 13 /*Okolo3D = 13*/,
    Owwielokat3D = 14, Opcx = 0, //Opoint3D = 0,
    ONoObiect = 16, Okoniec=0xf};

enum OBIEKTT2 { O2NieOkreslony=-1, O2NoBlockS,O2BlockDim, O2BlockPline, O2BlockAparat, O2BlockDXF, O2BlockSpecial, O2BlockHatch25, O2BlockHatch50} ;

enum Pline_Type { PL_OTHER = 0, PL_PLINE = 1, PL_POLYGON = 'P', PL_RECTANGLE = 'R', PL_HATCH = 'H',
    PL_ELLIPSE = 'E', PL_SKETCH = 'S', PL_TRACE = 'T', PL_CURVE = 'C',
    PL_ELLIPSE_FILL = 2, PL_ELLIPSE_ARC = 3, PL_PLYTA  = 'A', PL_OTWOR = 'B', PL_SIEC = 'n', PL_SHADOW = 13} ;

char B_PLINE = 'P';

#define Bdef   {Anormalny,OdBLOK,0,0,0,1,0,0,  B3, '\0', 0, 0,'\0'}
#define BDdef  {Anormalny,OdBLOK,0,0,0,1,0,0,  B3, '\0', 0, 0} ///TO CHECK

#define Ldef  {Anormalny,Olinia,0,0,0,1,0,0,  20, 0,7,64, 0,0,0,0}
#define ldef  {Anormalny,Oluk,0,0,0,1,0,0, 24, 0,7,64, 0,0,0, 0,0}

#pragma pack( 4 )

typedef
struct
{ unsigned atrybut  : 3;
    unsigned obiekt   : 4;
    unsigned obiektt1 : 2;
    unsigned obiektt2 : 3;
    unsigned obiektt3 : 1;
    unsigned widoczny : 1;
    unsigned przec    : 1;
    unsigned blok     : 1;
    unsigned int n ; //   : 32;
} NAGLOWEK;

typedef
struct
{ unsigned atrybut  : 3;
    unsigned obiekt   : 4;
    unsigned obiektt1 : 2;
    unsigned obiektt2 : 3;
    unsigned obiektt3 : 1;
    unsigned widoczny : 1;
    unsigned przec    : 1;
    unsigned blok     : 1;
    unsigned int n ; //    : 32;
    unsigned warstwa  : 8;
    unsigned kolor    : 8;   //255 - przezroczysty - dla potrzeb stropu
    unsigned typ      : 8;
    float x1          ;  //32
    float y1          ;  //32
    float x2          ;  //32
    float y2          ;  //32   -> 20
} LINIA;
typedef  LINIA  * LINIA_;

typedef
struct
{ unsigned atrybut  : 3;
    unsigned obiekt   : 4;
    unsigned obiektt1 : 2;
    unsigned obiektt2 : 3;
    unsigned obiektt3 : 1;
    unsigned widoczny : 1;
    unsigned przec    : 1;
    unsigned blok     : 1;
    unsigned int n; //    :32;
    unsigned warstwa  : 8;
    unsigned kolor    : 8;
    unsigned typ      : 8;
/*       unsigned rezerwa1 : 1;*/
    float x,y,r;
    float kat1,kat2;
} LUK;
typedef  LUK  * LUK_;


#pragma pack ()
typedef
struct
{ unsigned atrybut  : 3;
    unsigned obiekt   : 4;
    unsigned obiektt1 : 2;
    unsigned obiektt2 : 3;
    unsigned obiektt3 : 1;
    unsigned widoczny : 1;
    unsigned przec    : 1;
    unsigned blok     : 1;
    unsigned int n ; //   : 32;
    char kod_obiektu ; // : 8;
    char rezerwa ; //     : 8;
    unsigned short dlugosc_opisu_obiektu :16 ;
    char opis_obiektu [1]   ;
} BLOK;
typedef  BLOK  * BLOK_;

typedef
struct
{
    unsigned atrybut : 3;
    unsigned obiekt : 4;
    unsigned obiektt1 : 2;
    unsigned obiektt2 : 3;
    unsigned obiektt3 : 1;
    unsigned widoczny : 1;
    unsigned przec : 1;
    unsigned blok : 1;
    unsigned int n; //    : 32;
    unsigned warstwa : 8;
    unsigned kolor : 8;
    unsigned typ : 8;
    unsigned temp1 : 1;  //OT3W_Move=0, OT3W_Drag=1
    unsigned shadowed : 1;
    unsigned npts : 5;  //qbic=3,quadratic=4, multipoints=5, max=32
    unsigned closed : 1;    //D3  //2D=0, 3D=1;
    unsigned lp : 16;  //can vary during drawing, ending with 8, but can be more for multipoints spline
    float xy[NumSplinePoints];  //just 8 points, maybe more for multipoints spline
} SPLINE;

typedef SPLINE *SPLINE_;

int global_nv;
double bulge0;
double start_x, start_y;
LUK *block_buffer=NULL;
LUK *block_buffer1=NULL;
int block_buffer_el_no=0;
int block_buffer_el_no_max=1000;

typedef struct
{
    BOOL b_line, b_solid ; 	/*narysowano linie, narysowano obszar*/
    double width1 ;		/*szerokosc poczatkowa pierwszego segmentu*/
    double width ;		/*szerokosc biezaca*/
    double bulge ;
    LINIA line ;
    int color_line ;
    //WIELOKAT solid ; //= S4def ;  //won't be used
} t_pline ;

static t_pline  s_pline = {FALSE, FALSE, 0, 0, 0, Ldef, 7}; //, S4def};
LINIA line_g = Ldef ;
double DF_PRECISION = 1.0E+5;
double DF_PRECISION1 = 1.0E+2;

#ifndef LINUX
BLOKD s_blockd = BDdef ;
#else
BLOK s_blockd = Bdef ;
#endif

static char *max_ptr(char *p1, char *p2)
{
  if (p1 > p2)
    return p1;
  else
    return p2;
}

int fnsplit (const char *path, char *drive, char *dir, char *name, char *ext)
{
  int flags = 0, len;
  const char *pp, *pe;

  if (drive)
    *drive = '\0';
  if (dir)
    *dir = '\0';
  if (name)
    *name = '\0';
  if (ext)
    *ext = '\0';

  pp = path;

  if ((isalpha((unsigned char )*pp)
       || strchr("[\\]^_`", *pp)) && (pp[1] == ':'))
  {
    flags |= DRIVE;
    if (drive)
    {
      strncpy(drive, pp, 2);
      drive[2] = '\0';
    }
    pp += 2;
  }

  pe = max_ptr(strrchr(pp, '\\'), strrchr(pp, '/'));
  if (pe)
  {
    flags |= DIRECTORY;
    pe++;
    len = (int)(pe - pp);
    if (dir)
    {
      strncpy(dir, pp, len);
      dir[len] = '\0';
    }
    pp = pe;
  }
  else
    pe = pp;

  /* Special case: "c:/path/." or "c:/path/.."
     These mean FILENAME, not EXTENSION.  */
  while (*pp == '.')
    ++pp;
  if (pp > pe)
  {
    flags |= FILENAME;
    if (name)
    {
      len = (int)(pp - pe);
      strncpy(name, pe, len);
      name[len] = '\0';
      /* advance name over '.'s so they don't get scragged later on when the
       * rest of the name (if any) is copied (for files like .emacs). - WJC
       */
      name+=len;
    }
  }

  pe = strrchr(pp, '.');
  if (pe)
  {
    flags |= EXTENSION;
    if (ext)
      strcpy(ext, pe);
  }
  else
    pe = strchr( pp, '\0');

  if (pp != pe)
  {
    flags |= FILENAME;
    len = (int)(pe - pp);
    if (name)
    {
      strncpy(name, pp, len);
      name[len] = '\0';
    }
  }

  if (strcspn(path, "*?[") < strlen(path))
    flags |= WILDCARDS;

  return flags;
}

/* ---------------------------------------------------------------------- */
/* auxiliary linear algebra functions */

/* subtract two vectors */
static dpoint_t sub(dpoint_t v, dpoint_t w) {
  dpoint_t r;

  r.x = v.x - w.x;
  r.y = v.y - w.y;
  return r;
}

/* inner product */
static double iprod(dpoint_t v, dpoint_t w) {
  return v.x * w.x + v.y * w.y;
}

/* cross product */
static double xprod(dpoint_t v, dpoint_t w) {
  return v.x * w.y - v.y * w.x;
}

/* calculate the DXF polyline "bulge" value corresponding to the angle
   between two vectors. In case of "infinity" return 0.0. */
static double bulge(dpoint_t v, dpoint_t w) {
  double v2, w2, vw, vxw, nvw;

  v2 = iprod(v, v);
  w2 = iprod(w, w);
  vw = iprod(v, w);
  vxw = xprod(v, w);
  nvw = sqrt(v2 * w2);

  if (vxw == 0.0) {
    return 0.0;
  }    

  return (nvw - vw) / vxw;
}

/* ---------------------------------------------------------------------- */
/* DXF output synthesis */

/* print with group code: the low-level DXF file format */
static int ship(FILE *fout, int gc, const char *fmt, ...) {
  va_list args;
  int r;
  int c;

  r = fprintf(fout, "%3d\n", gc);
  if (r < 0) {
    return r;
  }
  c = r;
  va_start(args, fmt);
  r = vfprintf(fout, fmt, args);
  va_end(args);
  if (r < 0) {
    return r;
  }
  c += r;
  r = fprintf(fout, "\n");
  if (r < 0) {
    return r;
  }
  c += r;
  return c;
}

/* output the start of a polyline */
static void ship_polyline(FILE *fout, const char *layer, int closed) {
  ship(fout, 0, "POLYLINE");
  ship(fout, 8, "%s", layer);
  ship(fout, 66, "%d", 1);
  ship(fout, 70, "%d", closed ? 1 : 0);
}

/* output a vertex */
static void ship_vertex(FILE *fout, const char *layer, dpoint_t v, double bulge) {
  ship(fout, 0, "VERTEX");
  ship(fout, 8, "%s", layer);
  ship(fout, 10, "%f", v.x);
  ship(fout, 20, "%f", v.y);
  ship(fout, 42, "%f", bulge);
}

void obru(double si,double co, double xp, double yp, double *xn,double *yn)
/*------------------------------------------------*/
{ *xn=+xp*co+yp*si;  	/*zgodny z kierunkiem ruchu wskazowek zegara*/
    *yn=-xp*si+yp*co;
}

void obrd(double si,double co, double xp, double yp, double *xn, double *yn)
/*------------------------------------------------*/
{ *xn=+xp*co-yp*si;	/*nie zgodny z kierunkiem ruchu wskazowek zegara*/
    *yn= xp*si+yp*co;
}

double Atan2 (double y, double x)
/*------------------------------*/
{
    if (fabs(y) < 1.0E-10 && fabs (x) < 1.0E-10)
    {
/*   Internal_Error (__LINE__,__FILE__) ;*/
        return 0 ;
    }
    return atan2 (y, x) ;
}

static double get_little_val (double df_lv, double df_x, double df_y)
/*-----------------------------------------------------------------*/
{
    double df_dd ;

    df_dd = fabs (df_x / df_lv) ;
    if (df_dd == 0)
    {
        df_dd = fabs (df_y / df_lv) ;
        if (df_dd == 0)
        {
            df_dd = 1 / df_lv;
        }
    }
    if (df_dd < 1 / df_lv)
    {
        df_dd = 1 / df_lv;
    }
    return df_dd ;
}

BOOL Check_if_LE (double x, double y)
/*----------------------------------*/
{
    BOOL retval ;

    retval = FALSE ;
    if (x <= y + get_little_val (DF_PRECISION, x, y))
    {
        retval = TRUE ;
    }
    return retval ;
}

BOOL Check_if_Equal (double x, double y)
/*---------------------------------------*/
{
    BOOL retval ;
    double dd ;

    retval = FALSE ;
    dd = get_little_val (DF_PRECISION, x, y) ;
    if (fabs (x - y) < dd)
    {
        retval = TRUE ;
    }
    return retval ;
}

BOOL Check_if_Equal1 (double x, double y)
/*---------------------------------------*/
{
    BOOL retval ;
    double dd ;

    retval = FALSE ;
    dd = get_little_val (DF_PRECISION1, x, y) ;
    if (fabs (x - y) < dd)
    {
        retval = TRUE ;
    }
    return retval ;
}

void POLYARC(double x_s, double y_s, double x_e, double y_e, double wpsc, LUK *l)
{ double x0,y0,xr,yr,xe,ye,xs,ys,dl,t;
    double a1,a2,si,co;
    double dkat;
    int znak_kata=0;
    double ws;

    /*wpsc stanowi wypuklosc*/
    /*kat ws jest wyznaczony na podstawie wypuklosci wg wzoru*/
    /*ws = atan (wpsc) * 4 */
    // dkat = Grid_to_Rad (ws) ;
    if (wpsc<0) znak_kata=1;

    ws = atan(fabs(wpsc)) * 4;
    if (znak_kata==1) dkat=Pi2-ws; else dkat=ws;
    //dkat = Angle_Normal (ws) ;
    x0=(x_e+x_s)/2;
    y0=(y_e+y_s)/2;
    xs=x_s-x0; ys=y_s-y0;
    dl=sqrt(xs*xs+ys*ys);
    si=ys/dl;
    co=xs/dl;
    obru(si,co,xs,ys,&xs,&ys);
    xr=0;
    t=tan(dkat/2);
    if(fabs(t)<OZero)  t=(t>=0 ? OZero : -OZero);
    yr=-xs/t;
    l->r=sqrt(xs*xs+yr*yr);
    obrd(si,co,xr,yr,&xr,&yr);
    l->x=xr+x0; l->y=yr+y0;
    xs=x_s-l->x;  xe=x_e-l->x;
    ys=y_s-l->y;  ye=y_e-l->y;
    a1=Atan2(ys,xs);
    a2=Atan2(ye,xe);
    if (znak_kata==0)
    {
        l->kat1=a1;
        l->kat2=a2;
    }
    else
    {
        l->kat1=a2;
        l->kat2=a1;
    }
}

void check_buffer(void)
{
    if (block_buffer_el_no>=block_buffer_el_no_max)
    {
        block_buffer_el_no_max+=1000;
        block_buffer1=realloc(block_buffer, block_buffer_el_no_max*sizeof(LUK));
        block_buffer=block_buffer1;
    }
}

static void buffer_line(LINIA *L)
{
    check_buffer();
    memmove(&block_buffer[block_buffer_el_no], L, sizeof(LINIA));
    block_buffer_el_no++;
}

static void buffer_arc(LUK *l)
{
        check_buffer();
        memmove(&block_buffer[block_buffer_el_no], l, sizeof(LUK));
        block_buffer_el_no++;
}

static void ship_closing_line_alx(FILE *fout, const char *layer, double bulge)
{
    LINIA L=Ldef;
    LUK l=ldef;

    line_g.x2=start_x;
    line_g.y2=start_y;

    if (s_pline.b_line==TRUE)
    {
        if (Check_if_Equal1(s_pline.bulge,0.0))
        {
            L.x1=s_pline.line.x1;
            L.y1=s_pline.line.y1;
            L.x2=s_pline.line.x2;
            L.y2=s_pline.line.y2;
            L.warstwa=*layer;
            ////if (to_block==1) L.obiektt2=O2BlockDXF;
            ////else
            L.obiektt2 = O2BlockPline;
            L.kolor=7;
            L.typ=64;  //thick
            L.obiektt3=0;
            L.blok=1;
            //if (NULL == dodaj_obiekt ((BLOK*)base_adr, &L)) return 0;
            //if (fwrite(&L, sizeof(L), 1, fout) != 1) return;
            buffer_line(&L);
        }
        else
        {
            POLYARC(s_pline.line.x1, s_pline.line.y1, s_pline.line.x2, s_pline.line.y2, s_pline.bulge, &l);
            l.warstwa=*layer;
            l.obiektt2 = O2BlockPline;
            l.kolor=7;
            l.typ=64;
            l.obiektt3=0;
            l.blok=1;
            if ((!Check_if_LE (l.r, 0)) && (!Check_if_Equal (l.kat1, l.kat2))) {
                //if (fwrite(&l, sizeof(l), 1, fout) != 1) return;
                buffer_arc(&l);
            }
        }
    }

    memcpy (&s_pline.line, &line_g, sizeof(line_g)) ;

    s_pline.bulge = bulge0;
    bulge0 = bulge;
    //s_pline.color_line = line_g.kolor ;
    //line_g_x=line_g.x1;
    //line_g_y=line_g.y1;
    line_g.x1=line_g.x2;
    line_g.y1=line_g.y2;
    s_pline.b_line = TRUE ;

}

static void ship_line_end_alx(FILE *fout, const char *layer)
{
    LINIA L=Ldef;
    LUK l=ldef;

    if (s_pline.b_line==TRUE)
    {
        if (Check_if_Equal1(s_pline.bulge,0.0))
        {
            L.x1=s_pline.line.x1;
            L.y1=s_pline.line.y1;
            L.x2=s_pline.line.x2;
            L.y2=s_pline.line.y2;
            L.warstwa=*layer;
            ////if (to_block==1) L.obiektt2=O2BlockDXF;
            ////else
            L.obiektt2 = O2BlockPline;
            L.kolor=7;
            L.typ=64;  //thick
            L.obiektt3=0;
            L.blok=1;
            //if (NULL == dodaj_obiekt ((BLOK*)base_adr, &L)) return 0;
            //if (fwrite(&L, sizeof(L), 1, fout) != 1) return;
            buffer_line(&L);
        }
        else
        {
            POLYARC(s_pline.line.x1, s_pline.line.y1, s_pline.line.x2, s_pline.line.y2, s_pline.bulge, &l);
            l.warstwa=*layer;
            l.obiektt2 = O2BlockPline;
            l.kolor=7;
            l.typ=64;
            l.obiektt3=0;
            l.blok=1;
            if ((!Check_if_LE (l.r, 0)) && (!Check_if_Equal (l.kat1, l.kat2))) {
                //if (fwrite(&l, sizeof(l), 1, fout) != 1) return;
                buffer_arc(&l);
            }

        }
    }

}


static void ship_vertex_alx(FILE *fout, const char *layer, dpoint_t v, double bulge) {

    LINIA L=Ldef;
    LUK l=ldef;

    //ship(fout, 0, "VERTEX");
    //ship(fout, 8, "%s", layer);
    //ship(fout, 10, "%f", v.x);
    //ship(fout, 20, "%f", v.y);
    //ship(fout, 42, "%f", bulge);
    if (global_nv==0)
    {
        start_x = v.x;
        start_y = v.y;
        line_g.x1=v.x;
        line_g.y1=v.y;
        bulge0=bulge;
        block_buffer_el_no=0;
    }
    else
    {

        line_g.x2=v.x;
        line_g.y2=v.y;

        if (s_pline.b_line==TRUE)
        {
            if (Check_if_Equal1(s_pline.bulge,0.0))
            {
                L.x1=s_pline.line.x1;
                L.y1=s_pline.line.y1;
                L.x2=s_pline.line.x2;
                L.y2=s_pline.line.y2;
                L.warstwa=*layer;
                ////if (to_block==1) L.obiektt2=O2BlockDXF;
                ////else
                L.obiektt2 = O2BlockPline;
                L.kolor=7;
                L.typ=64;  //thick
                L.obiektt3=0;
                L.blok=1;
                //if (NULL == dodaj_obiekt ((BLOK*)base_adr, &L)) return 0;
                //if (fwrite(&L, sizeof(L), 1, fout) != 1) return;
                buffer_line(&L);
            }
            else
            {
                POLYARC(s_pline.line.x1, s_pline.line.y1, s_pline.line.x2, s_pline.line.y2, s_pline.bulge, &l);
                l.warstwa=*layer;
                l.obiektt2 = O2BlockPline;
                l.kolor=7;
                l.typ=64;
                l.obiektt3=0;
                l.blok=1;
                if ((!Check_if_LE (l.r, 0)) && (!Check_if_Equal (l.kat1, l.kat2))) {
                    //if (fwrite(&l, sizeof(l), 1, fout) != 1) return;
                    buffer_arc(&l);
                }
            }
        }

        memcpy (&s_pline.line, &line_g, sizeof(line_g)) ;

        s_pline.bulge = bulge0;
        bulge0 = bulge;
        //s_pline.color_line = line_g.kolor ;
        //line_g_x=line_g.x1;
        //line_g_y=line_g.y1;
        line_g.x1=line_g.x2;
        line_g.y1=line_g.y2;
        s_pline.b_line = TRUE ;
    }

    global_nv++;

}

/* output the end of a polyline */
static void ship_seqend(FILE *fout) {
  ship(fout, 0, "SEQEND");
}

/* output a comment */
static void ship_comment(FILE *fout, const char *comment) {
  ship(fout, 999, "%s", comment);
}

/* output the start of a section */
static void ship_section(FILE *fout, const char *name) {
  ship(fout, 0, "SECTION");
  ship(fout, 2, "%s", name);
}

static void ship_endsec(FILE *fout) {
  ship(fout, 0, "ENDSEC");
}

static void ship_eof(FILE *fout) {
  ship(fout, 0, "EOF");
}

/* ---------------------------------------------------------------------- */
/* Simulated quadratic and bezier curves */

/* Output vertices (with bulges) corresponding to a smooth pair of
   circular arcs from A to B, tangent to AC at A and to CB at
   B. Segments are meant to be concatenated, so don't output the final
   vertex. */
static void pseudo_quad(FILE *fout, const char *layer, dpoint_t A, dpoint_t C, dpoint_t B) {
  dpoint_t v, w;
  double v2, w2, vw, vxw, nvw;
  double a, b, c, y;
  dpoint_t G;
  double bulge1, bulge2;

  v = sub(A, C);
  w = sub(B, C);

  v2 = iprod(v, v);
  w2 = iprod(w, w);
  vw = iprod(v, w);
  vxw = xprod(v, w);
  nvw = sqrt(v2 * w2);

  a = v2 + 2*vw + w2;
  b = v2 + 2*nvw + w2;
  c = 4*nvw;
  if (vxw == 0 || a == 0) {
    goto degenerate;
  }
  /* assert: a,b,c >= 0, b*b - a*c >= 0, and 0 <= b - sqrt(b*b - a*c) <= a */
  y = (b - sqrt(b*b - a*c)) / a;
  G = interval(y, C, interval(0.5, A, B));

  bulge1 = bulge(sub(A,G), v);
  bulge2 = bulge(w, sub(B,G));

  ship_vertex(fout, layer, A, -bulge1);
  ship_vertex(fout, layer, G, -bulge2);
  return;

 degenerate:
  ship_vertex(fout, layer, A, 0);

  return;
}

static void pseudo_quad_alx(FILE *fout, const char *layer, dpoint_t A, dpoint_t C, dpoint_t B) {
    dpoint_t v, w;
    double v2, w2, vw, vxw, nvw;
    double a, b, c, y;
    dpoint_t G;
    double bulge1, bulge2;

    v = sub(A, C);
    w = sub(B, C);

    v2 = iprod(v, v);
    w2 = iprod(w, w);
    vw = iprod(v, w);
    vxw = xprod(v, w);
    nvw = sqrt(v2 * w2);

    a = v2 + 2*vw + w2;
    b = v2 + 2*nvw + w2;
    c = 4*nvw;
    if (vxw == 0 || a == 0) {
        goto degenerate;
    }
    /* assert: a,b,c >= 0, b*b - a*c >= 0, and 0 <= b - sqrt(b*b - a*c) <= a */
    y = (b - sqrt(b*b - a*c)) / a;
    G = interval(y, C, interval(0.5, A, B));

    bulge1 = bulge(sub(A,G), v);
    bulge2 = bulge(w, sub(B,G));

    ship_vertex_alx(fout, layer, A, -bulge1);
    ship_vertex_alx(fout, layer, G, -bulge2);
    return;

    degenerate:
    ship_vertex_alx(fout, layer, A, 0);

    return;
}


/* produce a smooth from A to D, tangent to AB at A and to CD at D.
   This is similar to a Bezier curve, except that our curve will be
   made up of up to 4 circular arcs. This is particularly intended for
   the case when AD and BC are parallel. Like arcs(), don't output the
   final vertex. */
static void pseudo_bezier(FILE *fout, const char *layer, dpoint_t A, dpoint_t B, dpoint_t C, dpoint_t D) {
  dpoint_t E = interval(0.75, A, B);
  dpoint_t G = interval(0.75, D, C);
  dpoint_t F = interval(0.5, E, G);

  pseudo_quad(fout, layer, A, E, F);
  pseudo_quad(fout, layer, F, G, D);
  return;
}

static void pseudo_bezier_alx(FILE *fout, const char *layer, dpoint_t A, dpoint_t B, dpoint_t C, dpoint_t D) {
    dpoint_t E = interval(0.75, A, B);
    dpoint_t G = interval(0.75, D, C);
    dpoint_t F = interval(0.5, E, G);

    pseudo_quad_alx(fout, layer, A, E, F);
    pseudo_quad_alx(fout, layer, F, G, D);
    return;
}

/* ---------------------------------------------------------------------- */
/* functions for converting a path to a DXF polyline */

/* do one path. */
static int dxf_path_dxf(FILE *fout, const char *layer, potrace_curve_t *curve, trans_t t) {
  int i;
  dpoint_t *c, *c1;
  int n = curve->n;

  ship_polyline(fout, layer, 1);

  for (i=0; i<n; i++)
  {
    c = curve->c[i];
    c1 = curve->c[mod(i-1,n)];
    switch (curve->tag[i]) {
    case POTRACE_CORNER:
      ship_vertex(fout, layer, trans(c1[2], t), 0);
      ship_vertex(fout, layer, trans(c[1], t), 0);
      break;
    case POTRACE_CURVETO:
      pseudo_bezier(fout, layer, trans(c1[2], t), trans(c[0], t), trans(c[1], t), trans(c[2], t));
      break;
    }
  }
  ship_seqend(fout);
  return 0;
}


static int ship_polyline_block_alx(FILE *fout, const char *layer, int closed) {
    char c_pltype ;
    long ex_block_pos;

    s_blockd.blok=1;
    s_blockd.n = B3 + sizeof (c_pltype) ;

    //printf("ship_polyline_block_alx %d\n",s_blockd.n);

    s_blockd.kod_obiektu = B_PLINE ;
    s_blockd.dlugosc_opisu_obiektu = sizeof(c_pltype) ;
    c_pltype = PL_PLINE ;
    s_blockd.opis_obiektu[0]=c_pltype;
    if (fwrite(&s_blockd, sizeof(s_blockd), 1, fout) != 1) return 1;
#ifdef LINUX
    ex_block_pos=ftell(fout)-3;
    int fn_pos_ex=fseek(fout, ex_block_pos, SEEK_SET);
#endif
    //if (fwrite(&c_pltype, sizeof(char), 1, fout) != 1) return 1;
    //int fn_pos_ex1=fseek(fout, ex_block_pos, SEEK_SET);
    return 0;
}

static int update_polyline_block_alx(FILE *fout, unsigned int n) {

    s_blockd.n = n;

     //printf("update_polyline_block_alx %d\n",s_blockd.n);

    if (fwrite(&s_blockd, sizeof(s_blockd)-4, 1, fout) != 1) return 1;
    return 0;
}

static int dxf_path_alx(FILE *fout, const char *layer, potrace_curve_t *curve, trans_t t) {
    int i;
    dpoint_t *c, *c1;
    int n = curve->n;
    long polyline_block_pos, polyline_block_begins_pos, polyline_block_ends_pos;
    unsigned int polyline_block_size=0;
    int b_n_off;
    NAGLOWEK *nag;
    LINIA *L;
    LUK *l;

    polyline_block_pos=ftell(fout);
    ship_polyline_block_alx(fout, layer, 1);
    polyline_block_begins_pos=ftell(fout);

    global_nv = 0;
    s_pline.b_line=FALSE;

    for (i=0; i<n; i++)
    {
        c = curve->c[i];
        c1 = curve->c[mod(i - 1, n)];
        switch (curve->tag[i]) {
            case POTRACE_CORNER:
                ship_vertex_alx(fout, layer, trans(c1[2], t), 0);
                ship_vertex_alx(fout, layer, trans(c[1], t), 0);
                break;
            case POTRACE_CURVETO:
                pseudo_bezier_alx(fout, layer, trans(c1[2], t), trans(c[0], t), trans(c[1], t), trans(c[2], t));
                break;
        }
    }

    //closing
    ship_closing_line_alx(fout, layer, bulge0);
    ship_line_end_alx(fout, layer);

    //WRITING block from buffer
    //for (i=block_buffer_el_no-1; i>=0; i--)
    for (i=0; i<block_buffer_el_no; i++)
    {
        nag=(NAGLOWEK*)&block_buffer[i];
        switch (nag->obiekt)
        {
            case Olinia:
                L=(LINIA*)&block_buffer[i];
                if (fwrite(L, sizeof(LINIA), 1, fout) != 1) return 1;
                break;
            case Oluk:
                l=(LUK*)&block_buffer[i];
                if (fwrite(l, sizeof(LUK), 1, fout) != 1) return 1;
                break;
        }
    }
    ////

    polyline_block_ends_pos=ftell(fout);
#ifdef LINUX
    b_n_off=5;
#else
    b_n_off=0;
#endif
    polyline_block_size += (polyline_block_ends_pos - polyline_block_begins_pos + b_n_off);

    int fn_pos=fseek(fout, polyline_block_pos, SEEK_SET);
    update_polyline_block_alx(fout, polyline_block_size);
    fn_pos=fseek(fout, polyline_block_ends_pos, SEEK_SET);

    return 0;

}

/* ---------------------------------------------------------------------- */
/* Backend. */

/* public interface for ALX */
int page_alx(FILE *fout, potrace_path_t *plist, imginfo_t *imginfo) {
  potrace_path_t *p;
  trans_t t;
  const char layer = '\00';
  long block_begins_pos, block_ends_pos;
  char drive[MAXDRIVE];
	char dir[MAXDIR];
	char file[MAXFILE];
	char ext[MAXEXT];
	int fileflags;

  /* set up the coordinate transform (rotation) */
  t.bb[0] = imginfo->trans.bb[0]+imginfo->lmar+imginfo->rmar;
  t.bb[1] = imginfo->trans.bb[1]+imginfo->tmar+imginfo->bmar;
  t.orig[0] = imginfo->trans.orig[0]+imginfo->lmar;
  t.orig[1] = imginfo->trans.orig[1]+imginfo->bmar;
  t.x[0] = imginfo->trans.x[0];
  t.x[1] = imginfo->trans.x[1];
  t.y[0] = imginfo->trans.y[0];
  t.y[1] = imginfo->trans.y[1];

  //ship_comment(fout, "DXF data, created by " POTRACE " " VERSION ", written by Peter Selinger 2001-2019");
  //ship_comment(fout, "ALX data, created by " POTRACE " " VERSION ", written by Marek Ratajczak 2023");

  /* header section */
  //ship_section(fout, "HEADER");

  /* variables */
  /*
  ship(fout, 9, "$ACADVER");
  ship(fout, 1, "AC1006");
  ship(fout, 9, "$EXTMIN");
  ship(fout, 10, "%f", 0.0);
  ship(fout, 20, "%f", 0.0);
  ship(fout, 30, "%f", 0.0);
  ship(fout, 9, "$EXTMAX");
  ship(fout, 10, "%f", t.bb[0]);
  ship(fout, 20, "%f", t.bb[1]);
  ship(fout, 30, "%f", 0.0);
  */

  //ship_endsec(fout);

  /* entities section */
  //ship_section(fout, "ENTITIES");

  //ALX block header

#ifndef LINUX
    BLOKD blok = BDdef;
#else
    BLOK blok = Bdef;
#endif

    char blok_naglowka[VERB_LEN] = VERB4_1;

    char block_name [Max_Spec_Block] ;
    char block_type [Max_Spec_Block] ;
    int flags = EBF_IP;
    BLOK  *b;
    double Px = 0.0;
    double Py = 0.0;
    int ex_block_pos, block_pos;
    long block_size = B3;

    block_name [0] ='\0';
    block_type [0] = '\0';

    //strcpy(block_name, "TEST BLOCK NAME");
    //strcpy(block_type, "TEST BLOCK TYPE");

    fileflags = fnsplit(info.filecomment, drive, dir, file, ext);
    //fileflags = fnsplit(info.infiles[0], drive, dir, file, ext);


    if (strlen(ext)>0)
    {
      strcat(file, ext);
    }

    strcat(file, "   ->VECTORIZED");

    strcpy(block_name, file);
    strcpy(block_type, file);

    long l_block_size = 0;

    float f_xip = 0;
    float f_yip = 0;
    int len_name = strlen(block_name) + 1;
    int len_type = strlen(block_type) + 1;

    block_size=blok.n;
    blok.kod_obiektu = 'E';
    blok.dlugosc_opisu_obiektu = sizeof(flags) + 2 * sizeof(f_xip) +
                                 sizeof(len_type) + len_type;
    block_size += blok.dlugosc_opisu_obiektu;
    blok.atrybut = Ablok;

    if (fwrite(blok_naglowka, VERB_LEN, 1, fout) != 1) goto error;
    if (fwrite(&Px, sizeof(double), 1, fout) != 1) goto error;
    if (fwrite(&Py, sizeof(double), 1, fout) != 1) goto error;
    if (fwrite(&len_name, sizeof(int), 1, fout) != 1) goto error;
    if (fwrite(block_name, len_name, 1, fout) != 1) goto error;

    block_pos = ftell(fout);
    if (fwrite(&blok, sizeof(blok), 1, fout) != 1) goto error;
#ifdef LINUX
    ex_block_pos=ftell(fout)-4;
    int fn_pos_ex=fseek(fout, ex_block_pos, SEEK_SET);
#endif
    if (fwrite(&flags, sizeof(int), 1, fout) != 1)goto error;
    if (fwrite(&f_xip, sizeof(f_xip), 1, fout) != 1)goto error;
    if (fwrite(&f_yip, sizeof(f_yip), 1, fout) != 1)goto error;
    if (fwrite(&len_type, sizeof(len_type), 1, fout) != 1)goto error;
    if (fwrite(block_type, len_type, 1, fout) != 1) goto error;

    block_begins_pos = ftell(fout);
  /* write paths */

  block_buffer=(LUK*)malloc(block_buffer_el_no_max*sizeof(LUK));

  list_forall (p, plist) {
    dxf_path_alx(fout, &layer, &p->curve, t);
  }

    if (block_buffer!=NULL) free(block_buffer);
    block_buffer_el_no=0;

  //in list_forall updated: size_blok += l;

  //ship_endsec(fout);
  //ship_eof(fout);

    block_ends_pos = ftell(fout);

    block_size += (block_ends_pos - block_begins_pos);

    int font_nomax = 0;
    if (fwrite(&font_nomax, sizeof(font_nomax), 1, fout) != 1) goto error;

    int fn_pos=fseek(fout, block_pos, SEEK_SET);

    //blok.n = (unsigned long)block_size;
    blok.n = (unsigned int)block_size;

    //printf("page_alx %d\n",blok.n);

    if (fwrite(&blok, sizeof(blok)-4, 1, fout) != 1) goto error;


  fflush(fout);
  return 0;

  error:
    fflush(fout);
    return 1;
}

