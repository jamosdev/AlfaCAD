#ifndef ANIMSEL_H_INCLUDED
#define ANIMSEL_H_INCLUDED

#include "demo.h"
#include "display.h"

int pick_animation_type(ANIMATION_TYPE *type);

#endif
