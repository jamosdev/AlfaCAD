#ifndef		__DEMO_TRIPLE_BUFFER_H__
#define		__DEMO_TRIPLE_BUFFER_H__

#include "updtedvr.h"

extern void select_triple_buffer(DEMO_SCREEN_UPDATE_DRIVER *driver);

#endif				/* __DEMO_TRIPLE_BUFFER_H__ */
