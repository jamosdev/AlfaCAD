/* Allegro data file object indexes, produced by grabber v2.1 + WIP */
/* Datafile: c:\allegro\examples\example.dat */
/* Date: Sun Dec  1 19:23:53 1996 */
/* Do not hand edit! */

#define BIG_FONT                         0        /* FONT */
#define SILLY_BITMAP                     1        /* BMP  */
#define THE_PALETTE                      2        /* PAL  */

