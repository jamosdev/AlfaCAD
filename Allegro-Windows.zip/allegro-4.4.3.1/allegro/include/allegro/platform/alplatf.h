
#define ALLEGRO_MSVC


/* These are always defined now. */
#define ALLEGRO_NO_ASM
#define ALLEGRO_USE_C
